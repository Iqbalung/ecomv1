$(document).ready(function() {
	var form_product = {
		load: {
			css: [

			],
			js: [

			],
			success: function() {
				form_product.init();
				form_product.listeners();
			}		
		},
		init: function() {
			var me = this;				

			app.get_data_list("[name=category_id]",app.data.site_url+"/master/category/get",{},{
			  	display_value:'category_name',
			  	value:'category_id'
			});

			app.get_data_list("[name=prod_suplier]",app.data.site_url+"/master/suplier/get",{},{
			  	display_value:'suplier_name',
			  	value:'suplier_name'
			});			
			 
		},
		listeners: function() {
			var me = this;			

			$('#btn-action-simpan').on('click', function(event) {
				event.preventDefault();
				me.save();
			});

			$('#btn-action-batal').on('click', function(event) {
				event.preventDefault();
				swal({
				  	title: "Batal menambah produk?",					  
				  	icon: "warning",
				  	buttons: true,
				  	buttons: ["Tidak", "Batal"],				  	
				})
				.then((isCancel) => {
				  if (isCancel) {					    
					me.reset_form();
				  }
				});
			});
			
		},
		reset_form:function() {
			var me = this;
			app.clear_form("#form-produck");
			$("[name=category_id]").select2("val", "");
			$("[name=prod_suplier]").select2("val", "");
		},
		save: function()
		{
			var me = this;
				form = $("#form-produck"),
				formData = new FormData(form[0]);

			app.body_mask();
			app.requestAjaxForm(app.data.site_url+"/product/form/save",formData,"POST",function(result){
				try
				{
					if (result.success)
					{
						swal("Information",result.msg,"success");
						me.reset_form();
					}
					else
					{
						swal("Information",result.msg,"warning");
					}
				}
				catch(e)
				{
					swal("Information",e,"warning");
				}	
			});
		},		
		selected: {},
		id: '',
		url: '',
		firstLoad:{
			list:false,
		},
		isLoad: false,
	};

	app.loader(form_product);
});