<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$autoload['packages'] = array();
$autoload['libraries'] = array('session', 'template', 'tp_upload', 'template_cetak');
$autoload['drivers'] = array();
$autoload['helper'] = array('url','tp_input_helper','tp_tanggal_helper', 'tp_mysqli_sp_helper');
$autoload['config'] = array();
$autoload['language'] = array();
$autoload['model'] = array();
