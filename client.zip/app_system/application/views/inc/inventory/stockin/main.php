
<div class="page-main page-transaksi-forstok">
    <div class="container-fluid">
        <!--page title-->
        <div class="pg-header">
            <div class="col-md-12">
                <div class="row">               
                    <div class="col-md-7">              
                        <h4>Stok Log Process</h4>
                    </div>
                    <div class="col-md-4 padding-5">                
                        <!-- <div class="input-group">
                                <input type="text" class="form-control f-search" placeholder="Search...">
                                <div class="input-group-append">
                                    <button class="btn btn-outline-secondary btn-success bg-white btn-f-search" type="button"><i class="fa fa-search"></i></button>
                                </div>
                            </div> -->
                    </div>
                </div>
            </div>
        </div>                    
        <div class="row">
            <div class="col-xl-12">
                <div class="card card-shadow mb-4">
                    <div class="card-body- pt-3 pb-4">
                        <div class="table-responsive">
                            <br>
                            <table id="table-transaction" class="table table-bordered table-striped" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th style="width: 90px;">Suplier</th>
                                        <th>Invoice Number</th>
                                        <th>Date</th>
                                        <th>Source</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody class="row-trx">                                           
                                </tbody>
                            </table>
                        </div>
                        <div class="col-md-12">
                            <nav aria-label="Page navigation" id="nav" style="padding: 0 10px;">
                                
                            </nav>
                        </div>  
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>        

<?php $this->view("inc/inventory/stockin/modal"); ?>

<script type="text/javascript" src="<?php echo config_item('url_app') ?>js/modules/inventory/stockin.js"></script>