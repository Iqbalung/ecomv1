<div class="page-main page-transaksi-forstok">
    <div class="container-fluid">
         <div class="pg-header">
            <div class="col-md-12">
                <div class="row">               
                    <div class="col-md-6">              
                        <h4 class="weight500 d-inline-block pr-3 mr-3 border-right"> Transaction</h4>
                        <nav aria-label="breadcrumb" class="d-inline-block ">
                            <ol class="breadcrumb p-0">
                                <li class="breadcrumb-item"><a href="#">Manage  Transaction</a></li>
                            </ol>
                        </nav>  
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-3 padding-5">                
                        <div class="input-group">
                                <input type="text" class="form-control f-search" placeholder="Search...">
                                <div class="input-group-append">
                                    <button class="btn btn-outline-secondary btn-success bg-white btn-f-search" type="button"><i class="fa fa-search"></i></button>
                                </div>
                            </div>
                    </div>
                    <div class="col-md-3 padding-5">                
                        <div class="input-group">
                                <select class="form-control input-sm js-example-basic-single f-select" name="f-select" style="width: 350px;">
                              <option selected value="">All State</option>
                              <option value="hold">Hold</option>
                              <option value="ready_to_ship">Ready to Shipped</option>
                              <option value="shipped">Shiped</option>
                              <option value="delivered">Deliverd</option>
                              <option value="awaiting_payment">Awaiting payment</option>
                              <option value="completed">Completed</option>
                            </select>
                            </div>
                    </div>
                     <div class="col-md-2 padding-5">                
                        <div class="input-group">
                            <input type="text" class="form-control f-date-start input-date date-from" value="01/01/2010">    
                        </div>
                    </div>
                     <div class="col-md-2 padding-5">                
                        <div class="input-group">
                            <input type="text" class="form-control f-date-start input-date date-to" value="<?php echo date('d/m/Y'); ?>">
                            
                        </div>
                    </div>
                    <div class="col-md-1 padding-5">
                        <button class="btn btn-sucess btn-flat btn-box bg-green btn-lg" id="btn-import">Import</button>
                    </div>
                    <div class="col-md-1 padding-5">
                        <a href="<?php echo site_url() ?>/transaction/direct" class="btn btn-sucess btn-flat btn-box bg-green btn-lg" >Add</a>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-3 padding-5">                
                        <div class="input-group">
                            <select class="form-control input-sm  f-mediasale" id="mediasale" name="f-mediasale" style="width: 350px;">
                              <option selected value="">All Mediasale</option>
                            </select>
                         </div>
                    </div>
                    <div class="col-md-3 padding-5">                
                        <div class="input-group">
                            <select class="form-control input-sm js-example-basic-single f-select" name="f-select" style="width: 350px;">
                                <option selected value="">Al Method</option>
                                <option value="direct">Direct</option>
                                <option value="auto">Import</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <br>              
        <div class="row">
            <div class="col-xl-12">
                <div class="card card-shadow mb-4">
                    <div class="card-body- pt-3 pb-4">
                        <div class="table-responsive">
                            <br>
                            <table style="margin: 10px;margin-right:40px;" id="table-transaction" class="table table-bordered table-striped" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th style="width: 90px;">Mediasale</th>
                                        <th>Invoice Number</th>
                                        <th>Date</th>
                                        <th>Item</th>
                                        <th>address</th>
                                         <th>State</th>
                                        <th>Total   </th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody class="row-trx">                                           
                                </tbody>
                            </table>
                        </div>
                        <div class="col-md-12">
                            <nav aria-label="Page navigation" id="nav" style="padding: 0 10px;">
                                
                            </nav>
                        </div>  
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>        
<script type="text/javascript">
    $(document).ready(function(){
        $('#origin_province').change(function(){
 
            var province_id=$('#origin_province').val();
            $.get('<?php echo site_url('simplelist/get_city_by_province/') ?>'+province_id, function(resp){
                // console.log(resp);
                $('#origin_city').html(resp);
            });
        });
    });
 
 
    // menampilkan kota tujuan pengiriman
    $(document).ready(function(){
        $('#destination_provice').change(function(){
 
            var province_id=$('#destination_provice').val();
            $.get('<?php echo site_url('simplelist/get_city_by_province/') ?>'+province_id, function(resp){
                // console.log(resp);
                $('#destination_city').html(resp);
            });
        });
    });
</script>
<?php $this->view("inc/transaction/forstok/modal"); ?>
<script type="text/javascript" src="<?php echo config_item('url_app') ?>js/modules/transaction/forstok/main.js"></script>