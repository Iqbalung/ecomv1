<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Form extends MY_Controller {

	public function __construct()
	{
		parent::__construct();		
		$this->load->model("M_product");
	}

	public function index()
	{
		$data = array(
			'data_app' => $this->get_data_app()
		);
		
		$this->template->display('inc/product/form', $data);
	}

	public function save()
	{
		$params = array(			    
			    "prod_id" => ifunsetempty($_POST,"prod_id",""),
			    "prod_code" => ifunsetempty($_POST,"prod_code",""),
			    "prod_name" => ifunsetempty($_POST,"prod_name",""),
			    "prod_name_short" => ifunsetempty($_POST,"prod_name_short",""),
			    "prod_colour" => ifunsetempty($_POST,"prod_colour",""),
			    "prod_desc" => ifunsetempty($_POST,"prod_desc",""),
			    "category_id" => ifunsetempty($_POST,"category_id",""),
			    "prod_suplier" => ifunsetempty($_POST,"prod_suplier",""),
			    "prod_barcode" => ifunsetempty($_POST,"prod_barcode",""),
			    "prod_stock_minimal" => ifunsetempty($_POST,"prod_stock_minimal",""),
			    "prod_piece" => ifunsetempty($_POST,"prod_piece","")
			);

		if (empty($params["prod_id"]))
		{
			$params['prod_id'] = $this->get_uuid();
			$res = $this->M_product->add($params);
		}
		else
		{
			$res = $this->M_product->update($params);
		}

		$out = $this->_respon($res,false,"create");
		echo json_encode($out);

	}
	
}

/* End of file Form.php */
/* Location: ./application/controllers/product/Form.php */