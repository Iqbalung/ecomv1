$(document).ready(function() {
	var indikator = {
		load: {
			css: [

			],
			js: [

			],
			success: function() {
				if(typeof data!="undefined"){
					data = JSON.parse(data);
					console.log(data);
					app.set_form_value($("#form-ubahindikator"),data);
				}
				$('.select2').select2();
				// definisikan validasi form
				$('#form-indikator').validate({
					ignore: [],
					errorPlacement: function(error, element) {
						error.insertAfter(element.parent());
					}
				});
				$('.btn-table button').on('click', function(event) {
					$($(this).attr('target')).modal('show');
				});

				$('.btn-ubahbukti').on('click', function(event) {
					$($(this).attr('target')).modal('show');
				});

				$('.btn-table button').on('click', function(event) {
					$($(this).addClass('active'));
				});

				
				$('#chooseFile').bind('change', function () {
				  var filename = $("#chooseFile").val();
				  if (/^\s*$/.test(filename)) {
				    $(".file-upload").removeClass('active');
				    $("#noFile").text("No file chosen..."); 
				  }
				  else {
				    $(".file-upload").addClass('active');
				    $("#noFile").text(filename.replace("C:\\fakepath\\", "")); 
				  }
				});
				
				// event simpan indikator
				app.submit_form('#form-indikator', '#btn-simpanindikator', function() {
					if ($('#form-indikator').valid()) { // cek is valid
						var formData = new FormData($('#form-indikator')[0]);
						app.body_mask();
						$.ajax({
								url: app.data.site_url + '/indikator/tambah/add_eselon1',
								method: "POST",
								data: formData,
								async: false,
								cache: false,
								contentType: false,
								processData: false,
							})
							.done(function(data) {
								var obj = $.parseJSON(data);
								app.body_unmask();
								$('#modal-notifikasi .modal-body').html(obj.msg);
								$('#modal-notifikasi').modal({
									keyboard: false,
									backdrop: 'static'
								});
								window.location.replace(app.data.site_url + "/perjanjian_kinerja");
							});
					}
				});

				app.submit_form('#form-bukti', '#btn-simpanbukti', function() {
					if ($('#form-bukti').valid()) { // cek is valid
						var formData = new FormData($('#form-bukti')[0]);
						$.ajax({
								url: app.data.site_url + '/indikator/Bukti/add',
								method: "POST",
								data: formData,
								async: false,
								cache: false,
								contentType: false,
								processData: false,
							})
							.done(function(data) {
								var obj = $.parseJSON(data);
								$('#modal-bukti').modal("hide");
								$('#modal-notifikasi .modal-body').html(obj.msg);
								$('#modal-notifikasi').modal({
									keyboard: false,
									backdrop: 'static'
								});
								setTimeout(
					            function() {
					              location.reload(true);
					            }, 1000);
							});
					}
				});

				app.submit_form('#form-ubahindikator', '#btn-updindikator', function() {
					if ($('#form-ubahindikator').valid()) { // cek is valid
						var formData = new FormData($('#form-ubahindikator')[0]);
						$.ajax({
								url: app.data.site_url + '/indikator/Ubah/simpan',
								method: "POST",
								data: formData,
								async: false,
								cache: false,
								contentType: false,
								processData: false,
							})
							.done(function(data) {
								var obj = $.parseJSON(data);
							
								$('#modal-notifikasi .modal-body').html(obj.msg);
								$('#modal-notifikasi').modal({
									keyboard: false,
									backdrop: 'static'
								});
							});
					}
				});
			}
		},

		selected: {},
		id: '',
		isLoad: false,
	};

	app.loader(indikator);
});