$(document).ready(function() {
	var news = {
		load: {
			css: [

			],
			js: [

			],
			success: function() {
				news.get_news();
				news.get_galery();
				news.get_video();
				if(typeof data!="undefined"){
					data = JSON.parse(data);
					console.log(data);
					app.set_form_value($("#form-ubahnews"),data);
				}
				
				$('.select2').select2();

				// definisikan validasi form
				$('#form-indikator').validate({
					ignore: [],
					errorPlacement: function(error, element) {
						error.insertAfter(element.parent());
					}
				});
				$('.btn-table button').on('click', function(event) {
					$($(this).attr('target')).modal('show');
				});

				$('.btn-ubahbukti').on('click', function(event) {
					$($(this).attr('target')).modal('show');
				});

				$('.btn-table button').on('click', function(event) {
					$($(this).addClass('active'));
				});

				
				$('#chooseFile').bind('change', function () {
				  var filename = $("#chooseFile").val();
				  if (/^\s*$/.test(filename)) {
				    $(".file-upload").removeClass('active');
				    $("#noFile").text("No file chosen..."); 
				  }
				  else {
				    $(".file-upload").addClass('active');
				    $("#noFile").text(filename.replace("C:\\fakepath\\", "")); 
				  }
				});
				
				
				// event simpan indikator
				app.submit_form('#form-bukti', '#btn-simpanbukti', function() {
					if ($('#form-bukti').valid()) { // cek is valid
						var formData = new FormData($('#form-bukti')[0]);
						$.ajax({
								url: app.data.site_url + '/indikator/Bukti/add',
								method: "POST",
								data: formData,
								async: false,
								cache: false,
								contentType: false,
								processData: false,
							})
							.done(function(data) {
								var obj = $.parseJSON(data);
								$('#modal-bukti').modal("hide");
								$('#modal-notifikasi .modal-body').html(obj.msg);
								$('#modal-notifikasi').modal({
									keyboard: false,
									backdrop: 'static'
								});
								setTimeout(
					            function() {
					              location.reload(true);
					            }, 1000);
							});
					}
				});

				app.submit_form('#form-ubahnews', '#btn-updnews', function() {
					if ($('#form-ubahnews').valid()) { // cek is valid
						var formData = new FormData($('#form-ubahnews')[0]);
						$.ajax({
								url: app.data.site_url + '/dashboard/app/upd',
								method: "POST",
								data: formData,
								async: false,
								cache: false,
								contentType: false,
								processData: false,
							})
							.done(function(data) {
								var obj = $.parseJSON(data);
							
								$('#modal-notifikasi .modal-body').html(obj.msg);
								$('#modal-notifikasi').modal({
									keyboard: false,
									backdrop: 'static'
								});
							});
					}
				});
				app.submit_form('#form-news', '#btn-simpannews', function() {
					if ($('#form-news').valid()) { // cek is valid
						var formData = new FormData($('#form-news')[0]);
						$.ajax({
								url: app.data.site_url + '/dashboard/app/add',
								method: "POST",
								data: formData,
								async: false,
								cache: false,
								contentType: false,
								processData: false,
							})
							.done(function(data) {
								var obj = $.parseJSON(data);
							
								$('#modal-notifikasi .modal-body').html(obj.msg);
								$('#modal-notifikasi').modal({
									keyboard: false,
									backdrop: 'static'
								});
							});
					}
				});
			}
		},

		get_news : function(){
				$.ajax({
		          type: 'POST',
		          url: app.data.site_url + '/dashboard/app/get_news',
		          cache: false,
		          data: {
		          },
		          success: function (data) {
		              data = JSON.parse(data);
		              var my_grid = $("#list_berita");
		              $(".loader").remove();
		              if(data.length>0){
			              $.each(data, function(i, value){
			              	i = parseInt(i);
			              	i = i+1;
			                my_grid.append(`
	    					<div class="list-peringkat bg-biru">
	    						<div id="no">`+i+`.</div>
	    						<div id="text">`+value.judul+`</div>
	    						<div id="jml"><a href="`+app.data.site_url + '/dashboard/app/edit_news/'+value.id+`">Edit</a></div>
	    					</div>
			                `);
			              });    
		              }else{
		              	my_grid.append(`
		                  	<tr class="rowsasaran">
								<td>Belum Ada Data Sasaran</td>
								<td></td>
								<td align="center"></td>
							</tr>
			            `);
		              }
		          },
		          beforeSend: function() {
		          	/*var my_grid = $("#sasaransatker");
		          	grid.html(`<div class="loader"></div>`);*/
		               
		          }
	        });
		},

		get_video : function(){
				$.ajax({
		          type: 'POST',
		          url: app.data.site_url + '/dashboard/app/get_video',
		          cache: false,
		          data: {
		          },
		          success: function (data) {
		              data = JSON.parse(data);
		              var my_grid = $("#list_video");
		              $(".loader").remove();
		              if(data.length>0){
			              $.each(data, function(i, value){
			              	i = parseInt(i);
			              	i = i+1;
			                my_grid.append(`
	    					<div class="list-peringkat bg-biru">
	    						<div id="no">`+i+`.</div>
	    						<div id="text">`+value.judul+`</div>
	    						<div id="jml"><a href="`+app.data.site_url + '/dashboard/app/edit_news/'+value.id+`">Edit</a></div>
	    					</div>
			                `);
			              });    
		              }else{
		              	my_grid.append(`
		                  	<tr class="rowsasaran">
								<td>Belum Ada Data Sasaran</td>
								<td></td>
								<td align="center"></td>
							</tr>
			            `);
		              }
		          },
		          beforeSend: function() {
		          	/*var my_grid = $("#sasaransatker");
		          	grid.html(`<div class="loader"></div>`);*/
		               
		          }
	        });
		},

		get_galery : function(){
				$.ajax({
		          type: 'POST',
		          url: app.data.site_url + '/dashboard/app/get_galery',
		          cache: false,
		          data: {
		          },
		          success: function (data) {
		              data = JSON.parse(data);
		              var my_grid = $("#list_galery");
		              $(".loader").remove();
		              if(data.length>0){
			              $.each(data, function(i, value){
			              	i = parseInt(i);
			              	i = i+1;
			                my_grid.append(`
	    					<div class="list-peringkat bg-biru">
	    						<div id="no">`+i+`.</div>
	    						<div id="text">`+value.judul+`</div>
	    						<div id="jml"><a href="`+app.data.site_url + '/dashboard/app/edit_news/'+value.id+`">Edit</a></div>
	    					</div>
			                `);
			              });    
		              }else{
		              	my_grid.append(`
		                  	<tr class="rowsasaran">
								<td>Belum Ada Data Sasaran</td>
								<td></td>
								<td align="center"></td>
							</tr>
			            `);
		              }
		          },
		          beforeSend: function() {
		          	/*var my_grid = $("#sasaransatker");
		          	grid.html(`<div class="loader"></div>`);*/
		               
		          }
	        });
		},



		selected: {},
		id: '',
		isLoad: false,
	};

	app.loader(news);
});