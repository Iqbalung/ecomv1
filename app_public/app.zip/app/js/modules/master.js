$(document).ready(function() {
	var master = {
		load: {
			css: [

			],
			js: [

			],
			success: function() {
				master.buttonAction();
				master.initSatuanKerja();
				master.load_tantangan();

				// definisikan validasi form
				$('#form-tantangan').validate({
					ignore: [],
					errorPlacement: function(error, element) {
						error.insertAfter(element.parent());
					}
				});

				// definisikan validasi form
				$('#form-user').validate({
					ignore: [],
					errorPlacement: function(error, element) {
						error.insertAfter(element.parent());
					}
				});

				// event tab control
				$('.tab-control > div').on('click', function(event) {
					var target = $(this).attr('target'),
						modal = target.split('#'),
						url = $(this).attr('url');

					modal = '#modal-' + modal[1];
					$('.btn-table button').attr('modal', modal);
					$('.btn-table #btn-hapus').attr('url', url);

					$('.tab-control > div').removeClass('active');
					$(this).addClass('active');
					master.setEventAction($(this));
					$('.row.kotak').hide('400');
					$(target).show('400');
				});

				// event button tambah
				$('#btn-tambah').on('click', function(event) {
					var modal = $(this).attr('modal');
					app.clear_form($(modal).find('form'));
					$(modal).modal('show');
				});

				// event button ubah
				$('#btn-ubah').on('click', function(event) {
					var modal = $(this).attr('modal');
					app.clear_form($(modal).find('form'));
					app.set_form_value($(modal).find('form'), master.selected);
					$(modal).modal('show');
				});

				// event button hapus
				$('#btn-hapus').on('click', function(event) {
					var url = $(this).attr('url');

					master.url = app.data.site_url + '/master/' + url + '/del';
					master.id = master.selected.ID_TANTANGAN;
					$('#modal-konfirmasi').modal();
				});

				// event komfirmasi hapus data
				$('#modal-konfirmasi #btn-ya').on('click', function() {
					$.ajax({
							url: master.url,
							method: 'POST',
							data: {
								id: master.id
							}
						})
						.done(function(data) {
							var obj = $.parseJSON(data);

							master.load_tantangan();
						});
				});

				// event simpan tantangan
				app.submit_form('#form-tantangan', '#modal-tantangan #btn-simpan', function() {
					if ($('#form-tantangan').valid()) { // cek is valid
						var formData = new FormData($('#form-tantangan')[0]),
							url = ($('[name=ID_TANTANGAN]').val() == '') ? 'add' : 'upd';
						app.body_mask();
						$.ajax({
								url: app.data.site_url + '/master/tantangan/' + url,
								method: "POST",
								data: formData,
								async: false,
								cache: false,
								contentType: false,
								processData: false,
							})
							.done(function(data) {
								var obj = $.parseJSON(data);
								app.body_unmask();
								$('#modal-tantangan').modal('hide');
								master.load_tantangan();
								$('#modal-notifikasi .modal-body').html(obj.msg);
								$('#modal-notifikasi').modal({
									keyboard: false,
									backdrop: 'static'
								});
							});
					}
				});

				// event simpan user
				app.submit_form('#form-user', '#modal-user #btn-simpan', function() {
					if ($('#form-user').valid()) { // cek is valid
						var formData = new FormData($('#form-user')[0]),
							url = ($('[name=USERID]').val() == '') ? 'add' : 'upd';
						app.body_mask();
						$.ajax({
								url: app.data.site_url + '/master/user/' + url,
								method: "POST",
								data: formData,
								async: false,
								cache: false,
								contentType: false,
								processData: false,
							})
							.done(function(data) {
								var obj = $.parseJSON(data);
								app.body_unmask();
								$('#modal-user').modal('hide');
								master.load_tantangan();
								$('#modal-notifikasi .modal-body').html(obj.msg);
								$('#modal-notifikasi').modal({
									keyboard: false,
									backdrop: 'static'
								});
							});
					}
				});
				
			}
		},
		load_usergroup: function() {
			$.ajax({
					url: app.data.site_url + '/master/user/get_usergroup',
					method: 'GET',
					data: {}
				})
				.done(function(data) {
					var obj = $.parseJSON(data);

					$.each(obj.data, function(index, val) {

					});
				})
				.fail(function() {
					
				});
		},
		load_tantangan: function() {
			$.ajax({
					url: app.data.site_url + '/master/tantangan/get',
					method: 'GET',
					data: {},
					beforeSend: function() {
						$('#table-tantangan tbody').html(app.loading);
					}
				})
				.done(function(data) {
					var obj = $.parseJSON(data);

					if (obj.data.length > 0) {
						$('#table-tantangan tbody').html('');
					}

					$.each(obj.data, function(index, val) {
						var html = `
							<tr idx="` + index + `">
								<td>` + (index+1) + `</td>
								<td>` + val['NAMA_TANTANGAN'] + `</td>
							</tr>
						`;

						$('#table-tantangan tbody').append(html);
						$('#table-tantangan tr[idx=' + index + ']').data('data', val);
					});
				})
				.fail(function() {
					
				});

			$('#table-tantangan tbody').delegate('tr', 'click', function(event) {
				master.selected = $(this).data('data');

				$('#table-tantangan tbody tr').removeClass('active');
				$(this).addClass('active');
			});
		},
		initSatuanKerja: function() {					
			var me = this;
			$("div#tree-satuan-kerja").jstree({
				plugins: ["grid"],
				core: {
					data: {
						url: app.data.site_url + '/master/satker/get_tree_',
						dataType: 'json',
						 "data" : function (node) {                  
			                  return { id : node.id };
			              }
					},
					themes:{
						icons: false
					}
				},
				// configure tree table
				grid: {
					columns: [
						{ 														
							value: 'NAMA_SATKER',							
							width:'40%',
						}
					],
					resizable: false,
					draggable: false,
					contextmenu: false,						
					
				}
			});			
			$("#tree-satuan-kerja").on('changed.jstree', function(e, data) {
				if (me.treeSatkerSelected.length == 0) {
					me.treeSatkerSelected.push(data.node.data);
				}else{
					me.treeSatkerSelected = [];
					me.treeSatkerSelected.push(data.node.data);			 
				}
			});
		},
		setEventAction: function(tabactive) {
			var btn = $(".btn-table .btn-action");
			for (var i = 0, l = btn.length; i < l; ++i) {
				var cmp = $(btn[i]);
			    cmp.attr("action",cmp.attr("base-action")+"-"+(tabactive.attr('url').replace("#","")));
			}
		},
		buttonAction: function() {
			var me = this;

			$('button,a').on('click', function() {
                var action = $(this).attr('action');
                switch (action) {
                    case 'tambah-master-satuan-kerja':
                        me.tambah_satker();
                        break;
                    case 'ubah-master-satuan-kerja':
                        me.ubah_satker();
                        break;
                    case 'hapus-master-satuan-kerja':
                        me.hapus_satker();
                        break;                   
                }
            });
		},

		simpan_satker: function(params) {
			var me = this;
			var formData = new FormData($('#form-satker')[0]);
			app.body_mask();
			$.ajax({
					url: app.data.site_url + '/master/satker/save',
					method: "POST",
					data: formData,
					async: false,
					cache: false,
					contentType: false,
					processData: false,
				})
				.done(function(data) {
					$('#modal-form-master-satker').modal('hide');
					var obj = $.parseJSON(data);										
					$("div#tree-satuan-kerja").jstree('load_node', obj.id_parent);
					$("div#tree-satuan-kerja").jstree('open_all', obj.id_parent);
					$('#modal-notifikasi .modal-body').html(obj.msg);
					$('#modal-notifikasi').modal({
						keyboard: false,
						backdrop: 'static'
					});
				})
				.always(function(){
					app.body_unmask();
				});
		},

		tambah_satker: function() {
			var me = this;
			if (me.treeSatkerSelected.length == 1) {								
				$('#modal-form-master-satker').modal({
					keyboard: false,
					backdrop: 'static'
				});
				var data = {
					ID_SATKER_PARENT: me.treeSatkerSelected[0].ID_SATKER
				};
				$('#form-satker')[0].reset();
				app.set_form_value($('#form-satker'),data);
				$('#modal-form-master-satker #btn-simpan').off('click');
				$('#modal-form-master-satker #btn-simpan').on('click',function(){					
					me.simpan_satker();
				});
			}else{
				$('#modal-warning .modal-body').html("Pilih data terlebih dahulu");
				$('#modal-warning').modal({
					keyboard: false,
					backdrop: 'static'
				});
			}
		},

		ubah_satker: function() {
			var me = this;
			if (me.treeSatkerSelected.length == 1) {								
				$('#modal-form-master-satker').modal({
					keyboard: false,
					backdrop: 'static'
				});
				var data = me.treeSatkerSelected[0];
				data.ID_SATKER_PARENT = me.treeSatkerSelected[0].ID_SATKER				
				$('#form-satker')[0].reset();
				app.set_form_value($('#form-satker'),data);
				$('#modal-form-master-satker #btn-simpan').off('click');
				$('#modal-form-master-satker #btn-simpan').on('click',function(){					
					me.simpan_satker();
				});
			}else{
				$('#modal-warning .modal-body').html("Pilih data terlebih dahulu");
				$('#modal-warning').modal({
					keyboard: false,
					backdrop: 'static'
				});
			}
		},

		hapus_satker: function() {
			var me = this;
			if (me.treeSatkerSelected.length == 1) {
				var params = {
					ID_SATKER: me.treeSatkerSelected[0].ID_SATKER
				}
				me.konfirmasi("Hapus data ?",function(){
						app.body_mask();
						$.ajax({
							url: app.data.site_url + '/master/satker/del',
							method: "POST",
							data: params							
						})
						.done(function(data) {
							var obj = $.parseJSON(data);												
							$("div#tree-satuan-kerja").jstree('load_node');
						}).
						always(function(){
							app.body_unmask();
						});
				});
			}else{
				$('#modal-warning .modal-body').html("Pilih data terlebih dahulu");
				$('#modal-warning').modal({
					keyboard: false,
					backdrop: 'static'
				});
			}
		},

		konfirmasi: function(msg,action) {
			$('#modal-konfirmasi .modal-body').html(msg);
			$('#modal-konfirmasi').modal({
				keyboard: false,
				backdrop: 'static'
			});
			$('#modal-konfirmasi #btn-ya').off("click");
			$('#modal-konfirmasi #btn-ya').on("click",function(ths){
				action(ths);
			});
		},
		treeSatkerSelected:[],
		selected: {},
		id: '',
		url: '',
		isLoad: false,
	};

	app.loader(master);
});