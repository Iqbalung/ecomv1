$(document).ready(function() {
	var dashboard = {
		load: {
			css: [

			],
			js: [

			],
			success: function() {
				$('#btn-side').on('click', function(event) {
					$('#wrapper').toggleClass('toggled');
					if (!$('#wrapper').is('.toggled')) {
						$('#sidebar-wrapper div, #sidebar-wrapper label').not('#label').hide('400');
					} else {
						$('#sidebar-wrapper div, #sidebar-wrapper label').not('#label').show('400');
					}
				});
			}
		},
		selected: {	
		},
		id: '',
		isLoad: false,
	};
	app.loader(dashboard);
});