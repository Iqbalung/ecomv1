$(document).ready(function() {
	$('#wrapper').toggleClass('toggled');
	var perjanjian_kinerja = {
		load: {
			css: [

			],
			js: [

			],
			success: function() {
				perjanjian_kinerja.buttonAction();
				// event show/hide sidebar
				perjanjian_kinerja.treesatker();
				perjanjian_kinerja.setactivesasaran();
				$('#btn-side').on('click', function(event) {
					$('#wrapper').toggleClass('toggled');
					if (!$('#wrapper').is('.toggled')) {
						$('#sidebar-wrapper div, #sidebar-wrapper label').not('#label').hide('400');
					} else {
						$('#sidebar-wrapper div, #sidebar-wrapper label').not('#label').show('400');
					}
				});


				$(".keuangan").hide();
				$(".btn-tambahsasaran").hide();
				$(".btn-ubahsasaran").hide();
				$(".btn-hapussasaran").hide();
				$(".btn-tambahprogram").hide();
				$(".btn-ubahprogram").hide();
				$(".btn-hapusprogram").hide();
				$("#iks_link").hide();
				$("#iks_link2").hide();
				$("#iks_link3").show();
				//sasaran
				$( "table" ).on( "click", ".rowsasaran", function() {
					var satker = $("#treeunit").jstree("get_selected")[0];
					sasaran =  $(this).data("uid");
					$("#iks_link").attr("href", app.data.site_url+"/indikator/tambah/indikator/"+sasaran+"");
					$("#ikp_link").attr("href", app.data.site_url+"/program/tambah/program/"+sasaran+"");
					console.log(sasaran);
					perjanjian_kinerja.getindikatorsasaran(satker, sasaran);
				});
				
				//pilih indikator untuk diinsert sebagai indikator setiap program dari sater
				$('#iks_link2').on("click", function(){
					perjanjian_kinerja.pilihprogram();
				});

				$('#iks_link3').on("click", function(){
					perjanjian_kinerja.pilihkegiatan();
				});

				// event button sasaran
				$('.btn-table button').on('click', function(event) {
					$($(this).attr('target')).modal('show');
					var selectedtree = $("#treeunit").jstree("get_selected")[0];
					$("input[name='ID_SATKER']").val(selectedtree);
					$("input[name='id']").val("");
				});

				$('.btn-ubahsasaran').on('click', function(event) {
					perjanjian_kinerja.ubahsasaran();
				});

				// event simpan indikator
				app.submit_form('#form-sasaran', '#btn-simpansasaran', function() {
					if ($('#form-sasaran').valid()) { // cek is valid
						var formData = new FormData($('#form-sasaran')[0]);
						app.body_mask();
						$.ajax({
								url: app.data.site_url + '/Sasaran/save',
								method: "POST",
								data: formData,
								async: false,
								cache: false,
								contentType: false,
								processData: false,
							})
							.done(function(data) {
								app.body_unmask();
								var obj = $.parseJSON(data);
								$('#modal-sasaran').modal("hide");
								$('#modal-notifikasi .modal-body').html(obj.msg);
								$('#modal-notifikasi').modal({
									keyboard: false,
									backdrop: 'static'
								});
								var satker = $("#treeunit").jstree("get_selected")[0];
								perjanjian_kinerja.getsasaranbysatker(satker);
							});
					}
				});

				app.submit_form('#form-pilihnindikator', '#btn-simpanindikator', function() {
					if ($('#form-pilihnindikator').valid()) { // cek is valid
						var formData = new FormData($('#form-pilihnindikator')[0]);
						$.ajax({
								url: app.data.site_url + '/indikator/tambah/addmultiselect/',
								method: "POST",
								data: formData,
								async: false,
								cache: false,
								contentType: false,
								processData: false,
							})
							.done(function(data) {
								var obj = $.parseJSON(data);
								app.body_unmask();
								$('#modal-notifikasi .modal-body').html(obj.msg);
								$('#modal-notifikasi').modal({
									keyboard: false,
									backdrop: 'static'
								});
							});
					}
				});

				app.submit_form('#form-pilihkegiatan', '#btn-simpankegiatan', function() {
				if ($('#form-pilihnindikator').valid()) { // cek is valid
					var formData = new FormData($('#form-pilihkegiatan')[0]);
					$.ajax({
							url: app.data.site_url + '/kegiatan/kegiatan/addmultiselect',
							method: "POST",
							data: formData,
							async: false,
							cache: false,
							contentType: false,
							processData: false,
						})
						.done(function(data) {
							var obj = $.parseJSON(data);
							app.body_unmask();
							$('#modal-notifikasi .modal-body').html(obj.msg);
							$('#modal-notifikasi').modal({
								keyboard: false,
								backdrop: 'static'
							});
						});
					}
				});
			}
		},
		pilihprogram : function(){
			var sasaran = perjanjian_kinerja.getsasaranid();
			if(sasaran.length>1){
				var node = $("#treeunit").jstree("get_selected")[0];
				$.ajax({
		          type: 'POST',
		          url: app.data.site_url + '/program/program/get_indikatorprogram',
		          cache: false,
		          data: {
		            ID_SATKER : node,
		          },
		          success: function (data) {
		              data = JSON.parse(data);
		              console.log(data);
		              var sasaran = perjanjian_kinerja.getsasaranid();
		              var my_grid = $("#daftarprogram");
		              $("#form-pilihnindikator")[0].reset();
		              $(".rowindikatorsasaranmodal").remove();
		              /*$(".loader").remove();*/
		              if(data.length>0){
			              $.each(data, function(i, value){
			              	i = parseInt(i);
			              	i = i+1;
			                my_grid.append(`
			                 <tr class="rowindikatorsasaranmodal">
								<td>`+i+`
								<input type="checkbox" name="ID_INDIKATOR[]" value="`+value.ID_INDIKATOR+`" value="Yes" />
								</td>
								<td><a href="`+app.data.site_url+`/indikator/ubah/indikator/`+value.ID_INDIKATOR+`">`+value.NAMA_INDIKATOR+`</a></td>
								<td align="center">`+value.TARGET_INDIKATOR+` `+value.SATUAN_INDIKATOR+`</td>
								<td align="center"></td>
								<td align="center"></td>
								<td align="center"><i class="fa fa-exclamation-triangle is_tantangan" aria-hidden="true"></i></td>
								<td align="center"><i class="fa fa-download" aria-hidden="true"></i></td>
							</tr>
			                `);
			                 my_grid.append(`<input type="hidden" name="ID_SASARAN" value="`+sasaran+`" />`);
			              });    
		              }else{
		              	my_grid.append(`
		                  	<tr class="rowsasaran">
								<td>Belum Ada Data Sasaran</td>
								<td></td>
								<td align="center"></td>
							</tr>
			            `);
		              }
		          },
		          beforeSend: function() {
		          	/*var my_grid = $("#sasaransatker");
		          	grid.html(`<div class="loader"></div>`);*/
		               
		          }
	        	});
			}else{
				$('#modal-pilihprogram').modal('hide');
				alert("Pilih Sasaran Terlebih Dahulu");
			}
		},


		pilihkegiatan : function(){
			var sasaran = perjanjian_kinerja.getsasaranid();
			if(sasaran.length>1){
				var node = $("#treeunit").jstree("get_selected")[0];
				$.ajax({
		          type: 'POST',
		          url: app.data.site_url + '/kegiatan/kegiatan/get_indikatorkegiatan',
		          cache: false,
		          data: {
		            ID_SATKER : node,
		          },
		          success: function (data) {
		              data = JSON.parse(data);
		              console.log(data);
		              var sasaran = perjanjian_kinerja.getsasaranid();
		              var my_grid = $("#daftarprogramkegiatan");
		              $("#form-pilihkegiatan")[0].reset();
		              $(".rowindikatorsasaranmodal").remove();
		              if(data.length>0){
			              $.each(data, function(i, value){
			              	i = parseInt(i);
			              	i = i+1;
			                my_grid.append(`
			                 <tr class="rowindikatorsasaranmodal">
								<td>`+i+`
								<input type="checkbox" name="ID_INDIKATOR[]" value="`+value.ID_SASARAN+`" value="Yes" />
								</td>
								<td><a href="`+app.data.site_url+`/indikator/ubah/indikator/`+value.ID_INDIKATOR+`">`+value.NAMA_KEGIATAN+`</a></td>
								<td align="center">`+value.TARGET_KELUARANKUA+`</td>
								<td align="center"></td>
								<td align="center"></td>
								<td align="center"><i class="fa fa-exclamation-triangle is_tantangan" aria-hidden="true"></i></td>
								<td align="center"><i class="fa fa-download" aria-hidden="true"></i></td>
							</tr>
			                `);
			              });    
			              my_grid.append(`<input type="hidden" name="ID_SASARAN" value="`+sasaran+`" />`);
		              }else{
		              	my_grid.append(`
		                  	<tr class="rowsasaran">
								<td>Belum Ada Data Sasaran</td>
								<td></td>
								<td align="center"></td>
							</tr>
			            `);
		              }
		          },
		          beforeSend: function() {
		          	/*var my_grid = $("#sasaransatker");
		          	grid.html(`<div class="loader"></div>`);*/
		               
		          }
	        	});
			}else{
				$('#modal-pilihprogram').modal('hide');
				alert("Pilih Sasaran Terlebih Dahulu");
			}
		},

		ubahsasaran: function(){
			var id = perjanjian_kinerja.getsasaranid();
			sasaran = $('.rowsasaran.active').data('sasaran');
			strategi = $('.rowsasaran.active').data('strategi');
			app.set_form_value($("#form-sasaran"),{
				id : id,
				sasaran : sasaran,
				strategi : strategi
			});
		},

		treesatker: function() {
			$('#treeunit')
				.on('changed.jstree', function(e, data) {
					if (typeof data.node != 'undefined') {
						$("#treeunit").jstree("get_selected")[0];
						var node = data.node.id;
						perjanjian_kinerja.getsasaranbysatker(node);
					}
				})
				.on('loaded.jstree', function(e, data) {
					// var node = (app.data.user.usergroupid == 2) ? app.data.user.satkerid : '01';

					// $("#treeunit").jstree('open_node', node);
					// $("#treeunit").jstree('select_node', node);
				})
				.jstree({
					core: {
						data: {
							url: app.data.site_url + '/master/satker/get_tree',
							dataType: 'json',
							 "data" : function (node) {                  
				                  return { id : node.id };
				              }
						}
					},
					plugins: ['json_data', 'search']
				});
		},

		getindikatorsasaran : function(satker,sasaran){	
			var eselon = perjanjian_kinerja.checkEselon(satker);
			if(eselon==1){
				$('#iks_link').show();
				$(".rowindikatorprogram").remove();
				$(".rowindikatorsasaran").remove();

				app.body_mask();
				$.ajax({
		          type: 'POST',
		          url: app.data.site_url + '/sasaran/get_indikatorsasaran',
		          cache: false,
		          data: {
		            ID_SASARAN : sasaran,
		            TIPE : "1"
		          },
		          success: function (data) {
		              data = JSON.parse(data);
		              datagrid = data.data;
		              console.log(data);
		              $(".rowindikatorsasaran").remove();
		              $(".rowformulasi").remove();
		              var my_grid = $("#indikatorsasaran");
		              /*$(".loader").remove();*/
		              app.body_unmask();
		              if(datagrid.length>0){
			              $.each(datagrid, function(i, value){
			              	i = parseInt(i);
			              	i = i+1;
			              	if(value.TOTAL==null){
			              		value.TOTAL = '0';
			              	}
			              	if(value.TARGET_INDIKATOR==null){
			              		value.TARGET_INDIKATOR = '0';
			              	}
			                my_grid.append(`
			                	<tr class="rowindikatorsasaran">
									<td>`+i+`</td>
									<td><a href="`+app.data.site_url+`/indikator/ubah/indikator/`+value.ID_INDIKATOR+`">`+value.NAMA_INDIKATOR+`</a></td>
									<td align="center">`+value.TARGET_INDIKATOR+`</td>
									<td align="center">`+value.TOTAL+`</td>
									<td align="center"></td>
									<td align="center"><i class="fa fa-exclamation-triangle is_tantangan" aria-hidden="true"></i></td>
									<td align="center"><i class="fa fa-download" aria-hidden="true"></i></td>
								</tr>
			                `);
			              });    
			            }else{
			              	my_grid.append(`
			                  	<tr class="rowindikatorsasaran">
									<td colspan="7">Belum Ada Data Indikator</td>
								</tr>
				            `);
			            }
			            $('#formulasiindikator').append(`
	         				<tr class="rowformulasi">
								<td colspan="2">Rata-Rata</td>
								<td align="center">`+app.round10(data.avg_target,2)+`%</td>
								<td align="center">`+data.avg_realisasi+`%</td>
								<td colspan="3" align="center">0%</td>
							</tr>
             			`);
		          },
		          beforeSend: function() {
		          	/*var my_grid = $("#sasaransatker");
		          	grid.html(`<div class="loader"></div>`);*/
		               
		          }
	        	});
	        	$.ajax({
		          type: 'POST',
		          url: app.data.site_url + '/program/program/get_programsasaran',
		          cache: false,
		          data: {
		            ID_SASARAN : sasaran,
		          },
		          success: function (data) {
		          	  app.body_unmask();
		              data = JSON.parse(data);
		              console.log(data);
		              $(".rowindikatorprogram").remove();
		              var my_grid = $("#indikatorprogram");
		              /*$(".loader").remove();*/
		              if(data.length>0){
			              $.each(data, function(i, value){
			              	console.log(value);
			              	i = parseInt(i);
			              	i = i+1;
			                my_grid.append(`
			                	<tr class="rowindikatorprogram">
									<td>`+i+`</td>
									<td><a href="">`+value.NAMA_PROGRAM+`</a></td>
									<td align="right">Rp. `+value.TARGET+`</td>
									<td align="right">`+value.REALISASI+`</td>
									<td align="center"><i class="fa fa-circle co-kurang" aria-hidden="true"></i></td>
									<td></td>
								</tr>
			                	
			                `);
			              });    
		              }else{
		              	my_grid.append(`
		                  	<tr class="rowindikatorprogram">
								<td colspan="7">Belum Ada Data Program</td>
							</tr>
			            `);
		              }

		              

		          },
		          beforeSend: function() {
		          	/*var my_grid = $("#sasaransatker");
		          	grid.html(`<div class="loader"></div>`);*/
		               
		          }
	        	});
	        	$.ajax({
		          type: 'POST',
		          url: app.data.site_url + '/program/program/get_programsasaran',
		          cache: false,
		          data: {
		            ID_SASARAN : sasaran,
		          },
		          success: function (data) {
		          	  app.body_unmask();
		              data = JSON.parse(data);
		              console.log(data);
		              $(".rowindikatorprogram").remove();
		              var my_grid = $("#indikatorprogram");
		              /*$(".loader").remove();*/
		              if(data.length>0){
			              $.each(data, function(i, value){
			              	console.log(value);
			              	i = parseInt(i);
			              	i = i+1;
			                my_grid.append(`
			                	<tr class="rowindikatorprogram">
									<td>`+i+`</td>
									<td><a href="`+app.data.site_url+`/program/ubah/program/`+value.ID_PROGRAM+`">`+value.NAMA_PROGRAM+`</a></td>
									<td align="right">Rp. `+value.TARGET+`</td>
									<td align="right">`+value.REALISASI+`</td>
									<td align="center"><i class="fa fa-circle co-kurang" aria-hidden="true"></i></td>
									<td></td>
								</tr>
			                `);
			              });    
		              }else{
		              	my_grid.append(`
		                  	<tr class="rowindikatorprogram">
								<td colspan="7">Belum Ada Data Program</td>
							</tr>
			            `);
		              }
		          },
		          beforeSend: function() {
		          	/*var my_grid = $("#sasaransatker");
		          	grid.html(`<div class="loader"></div>`);*/
		               
		          }
	        	});
			}
			if(eselon==2){
				app.body_mask();
				$(".rowformulasi").remove();
				$(".btn-tambahprogram").hide();
				$.ajax({
		          type: 'POST',
		          url: app.data.site_url + '/sasaran/get_indikatorsasaran',
		          cache: false,
		          data: {
		            ID_SASARAN : sasaran,
		            TIPE : "1"
		          },
		          success: function (data) {
		              data = JSON.parse(data);
		              datagrid = data.data;
		              app.body_unmask();
		              $(".rowindikatorsasaran").remove();
		              $(".rowformulasi").remove();
		              var my_grid = $("#indikatorsasaran");
		              /*$(".loader").remove();*/
		              if(datagrid.length>0){
			              $.each(datagrid, function(i, value){
			              	i = parseInt(i);
			              	i = i+1;
			                my_grid.append(`
			                	<tr class="rowindikatorsasaran">
									<td>`+i+`</td>
									<td><a href="`+app.data.site_url+`/indikator/ubah/indikator/`+value.ID_INDIKATOR+`">`+value.NAMA_INDIKATOR+`</a></td>
									<td align="center">`+value.TARGET_INDIKATOR+` `+value.SATUAN_INDIKATOR+`</td>
									<td align="center"></td>
									<td align="center"></td>
									<td align="center"><i class="fa fa-exclamation-triangle is_tantangan" aria-hidden="true"></i></td>
									<td align="center"><i class="fa fa-download" aria-hidden="true"></i></td>
								</tr>
			                `);
			                
			              });    
		              }else{
		              	my_grid.append(`
		                  	<tr class="rowindikatorsasaran">
								<td colspan="7">Belum Ada Data Indikator</td>
							</tr>
			            `);
		              }
		            $('#formulasiindikator').append(`
             			<tr class="rowformulasi">
							<td colspan="2">Rata-Rata</td>
							<td align="center">`+app.round10(data.avg_target,2)+`%</td>
							<td align="center">0%</td>
							<td colspan="3" align="center">0%</td>
						</tr>
             		`);
		          },
		          beforeSend: function() {
		          	/*var my_grid = $("#sasaransatker");
		          	grid.html(`<div class="loader"></div>`);*/
		               
		          }
	        	});
	        	$.ajax({
		          type: 'POST',
		          url: app.data.site_url + '/program/program/get_programsasaran',
		          cache: false,
		          data: {
		            ID_SASARAN : sasaran,
		          },
		          success: function (data) {
		              data = JSON.parse(data);
		              console.log(data);
		              $(".rowindikatorprogram").remove();
		              var my_grid = $("#indikatorprogram");
		              /*$(".loader").remove();*/
		              if(data.length>0){
			              $.each(data, function(i, value){
			              	console.log(value);
			              	i = parseInt(i);
			              	i = i+1;
			                my_grid.append(`
			                	<tr class="rowindikatorprogram">
									<td>`+i+`</td>
									<td><a href="`+app.data.site_url+`/program/ubah/program/`+value.ID_PROGRAM+`">`+value.NAMA_PROGRAM+`</a></td>
									<td align="right">Rp. `+value.TARGET+`</td>
									<td align="right">`+value.REALISASI+`</td>
									<td align="center"><i class="fa fa-circle co-kurang" aria-hidden="true"></i></td>
									<td></td>
								</tr>
			                	
			                `);
			              });    
		              }else{
		              	my_grid.append(`
		                  	<tr class="rowindikatorprogram">
								<td colspan="7">Belum Ada Data Program</td>
							</tr>
			            `);
		              }
		              

		          },
		          beforeSend: function() {
		          	/*var my_grid = $("#sasaransatker");
		          	grid.html(`<div class="loader"></div>`);*/
		               
		          }
	        	});

			}
			if(eselon==3){
				app.body_mask();
				$('.rowformulasi').remove();
	        	$(".rowindikatorprogram").remove();
				$.ajax({
		          type: 'POST',
		          url: app.data.site_url + '/sasaran/get_indikatorsasaran',
		          cache: false,
		          data: {
		            ID_SASARAN : sasaran,
		            TIPE : "1",
		          },
		          success: function (data) {
		              app.body_unmask();
		              data = JSON.parse(data);
		              datagrid = data.data;
		              $(".rowindikatorsasaran").remove();
		              var my_grid = $("#indikatorsasaran");
		              /*$(".loader").remove();*/
		              if(datagrid.length>0){
			              $.each(datagrid, function(i, value){
			              	i = parseInt(i);
			              	i = i+1;
			                my_grid.append(`
			                	<tr class="rowindikatorsasaran">
									<td>`+i+`</td>
									<td><a href="`+app.data.site_url+`/indikator/ubah/indikator/`+value.ID_INDIKATOR+`">`+value.NAMA_INDIKATOR+`</a></td>
									<td align="center">`+value.TARGET_INDIKATOR+` `+value.SATUAN_INDIKATOR+`</td>
									<td align="center"></td>
									<td align="center"></td>
									<td align="center"><i class="fa fa-exclamation-triangle is_tantangan" aria-hidden="true"></i></td>
									<td align="center"><i class="fa fa-download" aria-hidden="true"></i></td>
								</tr>
			                `);
			              });    
		              }else{
		              	my_grid.append(`
		                  	<tr class="rowindikatorsasaran">
								<td colspan="7">Belum Ada Data Indikator</td>
							</tr>
			            `);
		              }
	              	$('#formulasiindikator').append(`
         				<tr class="rowformulasi">
							<td colspan="2">Rata-Rata</td>
							<td align="center">`+app.round10(data.avg_target,2)+`%</td>
							<td align="center">`+data.avg_realisasi+`%</td>
							<td colspan="3" align="center">0%</td>
						</tr>
         			`);
		          },
		          beforeSend: function() {
		          	/*var my_grid = $("#sasaransatker");
		          	grid.html(`<div class="loader"></div>`);*/
		               
		          }
	        	});
	        	$.ajax({
		          type: 'POST',
		          url: app.data.site_url + '/program/program/get_programbykode',
		          cache: false,
		          data: {
		            ID_SASARAN : sasaran,
		          },
		          success: function (data) {
		              data = JSON.parse(data);
		              console.log(data);
		              $(".rowindikatorprogram").remove();
		              var my_grid = $("#indikatorprogram");
		              /*$(".loader").remove();*/
		              if(data.length>0){
			              $.each(data, function(i, value){
			              	i = parseInt(i);
			              	i = i+1;
			                my_grid.append(`
			                	<tr class="rowindikatorprogram">
									<td>`+i+`</td>
									<td><a href="">`+value.NAMA_PROGRAM+`</a></td>
									<td align="right">Rp. `+value.TARGET+`</td>
									<td align="right">`+value.REALISASI+`</td>
									<td align="center"><i class="fa fa-circle co-kurang" aria-hidden="true"></i></td>
									<td></td>
								</tr>
			                	
			                `);
			              });    
		              	}else{
			              	my_grid.append(`
			                  	<tr class="rowindikatorprogram">
									<td colspan="7">Belum Ada Data Program</td>
								</tr>
				            `);
		              	}

		          },
		          beforeSend: function() {
		          	/*var my_grid = $("#sasaransatker");
		          	grid.html(`<div class="loader"></div>`);*/
		               
		          }
	        	});
			}
			if(eselon==4){
				$("#iks_link3").show();
				app.body_mask();
	        	$(".rowindikatorprogram").remove();
	        	$('.rowformulasi').remove();
				$.ajax({
		          type: 'POST',
		          url: app.data.site_url + '/sasaran/get_indikatorsasaran',
		          cache: false,
		          data: {
		            ID_SASARAN : sasaran,
		            TIPE : "1",
		          },
		          success: function (data) {
					data = JSON.parse(data);
		            datagrid = data.data;
		            app.body_unmask();
		              $(".rowindikatorsasaran").remove();
		              var my_grid = $("#indikatorsasaran");
		              /*$(".loader").remove();*/
		              if(datagrid.length>0){
			              $.each(datagrid, function(i, value){
			              	i = parseInt(i);
			              	i = i+1;
			                my_grid.append(`
			                	<tr class="rowindikatorsasaran">
									<td>`+i+`</td>
									<td><a href="`+app.data.site_url+`/indikator/ubah/indikator/`+value.ID_INDIKATOR+`">`+value.NAMA_INDIKATOR+`</a></td>
									<td align="center">`+value.TARGET_INDIKATOR+` `+value.SATUAN_INDIKATOR+`</td>
									<td align="center"></td>
									<td align="center"></td>
									<td align="center"><i class="fa fa-exclamation-triangle is_tantangan" aria-hidden="true"></i></td>
									<td align="center"><i class="fa fa-download" aria-hidden="true"></i></td>
								</tr>
			                `);
			              });    
			            }else{
			              	my_grid.append(`
			                  	<tr class="rowindikatorsasaran">
									<td colspan="7">Belum Ada Data Indikator</td>
								</tr>
				            `);
			            }
			            $('#formulasiindikator').append(`
             				<tr class="rowformulasi">
								<td colspan="2">Rata-Rata</td>
								<td align="center">`+app.round10(data.avg_target,2)+`%</td>
								<td align="center">0%</td>
								<td colspan="3" align="center">0%</td>
							</tr>
             			`);
		          },
		          beforeSend: function() {
		          	/*var my_grid = $("#sasaransatker");
		          	grid.html(`<div class="loader"></div>`);*/
		               
		          }
	        	});
	        	$.ajax({
		          type: 'POST',
		          url: app.data.site_url + '/program/program/get_programbykode',
		          cache: false,
		          data: {
		            ID_SASARAN : sasaran,
		          },
		          success: function (data) {
		              data = JSON.parse(data);
		              console.log(data);
		              $(".rowindikatorprogram").remove();
		              var my_grid = $("#indikatorprogram");
		              /*$(".loader").remove();*/
		              if(data.length>0){
			              $.each(data, function(i, value){
			              	i = parseInt(i);
			              	i = i+1;

			                my_grid.append(`
			                	<tr class="rowindikatorprogram">
									<td>`+i+`</td>
									<td><a href="">`+value.NAMA_PROGRAM+`</a></td>
									<td align="right">Rp. `+value.TARGET+`</td>
									<td align="right">`+value.REALISASI+`</td>
									<td align="center"><i class="fa fa-circle co-kurang" aria-hidden="true"></i></td>
									<td></td>
								</tr>
			                	
			                `);
			              });    
		              }else{
		              	my_grid.append(`
		                  	<tr class="rowindikatorprogram">
								<td colspan="7">Belum Ada Data Program</td>
							</tr>
			            `);
		              }

		          },
		          beforeSend: function() {
		          	/*var my_grid = $("#sasaransatker");
		          	grid.html(`<div class="loader"></div>`);*/
		               
		          }
	        	});
			}
		},

		getsasaranbysatker: function(node) {
			var eselon = perjanjian_kinerja.checkEselon(node);
			perjanjian_kinerja.get_indikatorbysatker(node);
			perjanjian_kinerja.get_programsasaransatker(node);
			$.ajax({
		        type: 'POST',
		        url: app.data.site_url + '/sasaran/get_targetby',
		        cache: false,
		        data: {
		            ID_SATKER : node,
		        },
	          	success: function (data) {
	              data = JSON.parse(data);
	              console.log(data);
	              app.body_unmask();
	              var panel = $(".keuangan");
	              $("#panel-kuangan").remove();
	              /*$(".loader").remove();*/
	              if(data.length>0){
		              $.each(data, function(i, value){
		              	i = parseInt(i);
		              	i = i+1;
		                panel.append(		                `
		                <div id="panel-kuangan">
		                	<div id="jml">`+app.round10(value.PERSEN,2)+`</div>
							<div id="nilai">Rp. `+value.JUMLAH+`,-</div>
						</div>
		                `);
		              });    
	              }else{
	              	panel.append(
	              	`
	                  	
		            `
		            );
	              }
		        },
		        beforeSend: function() {
		          	/*var my_grid = $("#sasaransatker");
		          	grid.html(`<div class="loader"></div>`);*/
		               
		        }
	        });
			$(".btn-cetak").show();
	        $(".btn-cetak-eselon-4").hide();
			if(eselon==1){
				app.body_mask();
				$(".keuangan").show();
				$(".rowindikatorprogram").remove();
				$("#iks_link").show();
				$("#iks_link2").hide();
				$('.btn-tambahsasaran').show();
				$('.btn-ubahsasaran').show();
				$("#iks_link3").hide();
				$(".rowsasaran").remove();
				$(".btn-tambahprogram").show();
				$.ajax({
		          type: 'POST',
		          url: app.data.site_url + '/sasaran/get_sasasranbysatker',
		          cache: false,
		          data: {
		            ID_SATKER : node,
		          },
		          success: function (data) {
		              data = JSON.parse(data);
		              console.log(data);
		              app.body_unmask();
		              var my_grid = $("#sasaransatker");
		              $(".rowsasaran").remove();
		              if(data.length>0){
			              $.each(data, function(i, value){
			              	i = parseInt(i);
			              	i = i+1;
			                my_grid.append(`
			                  	<tr class="rowsasaran" data-uid="`+value.ID_SASARAN+`" data-sasaran="`+value.NAMA_SASARAN+`"data-strategi="`+value.STRATEGI_SASARAN+`" >
									<td>`+i+`</td>
									<td>`+value.NAMA_SASARAN+`</td>
									<td align="center"></td>
								</tr>
			                `);
			              });    
		              }else{
		              	my_grid.append(`
		                  	<tr class="rowsasaran">
								<td>Belum Ada Data Sasaran</td>
								<td></td>
								<td align="center"></td>
							</tr>
			            `);
		              }
		          },
		          beforeSend: function() {
		          	/*var my_grid = $("#sasaransatker");
		          	grid.html(`<div class="loader"></div>`);*/
		               
		          }
	        	});
			}
			if(eselon==2){
				$(".keuangan").show();
				$(".rowindikatorprogram").remove();
				$(".rowindikatorsasaran").remove();
				$(".btn-tambahsasaran").hide();
				$(".btn-ubahsasaran").hide();
				$(".btn-hapussasaran").hide();
				$(".btn-tambahprogram").hide();
				$(".btn-ubahprogram").hide();
				$(".btn-hapusprogram").hide();
				$("#iks_link").hide();
				$("#iks_link2").hide();
				$("#iks_link3").hide();
				app.body_mask();
				$.ajax({
			        type: 'POST',
			        url: app.data.site_url + '/sasaran/get_sasasranbysatker',
			        cache: false,
			        data: {
			            ID_SATKER : node,
			        },
		          	success: function (data) {
		             	data = JSON.parse(data);
		              	console.log(data);
		              	app.body_unmask();
		              	var my_grid = $("#sasaransatker");
		              	$(".rowsasaran").remove();
		              	if(data.length>0){
			              $.each(data, function(i, value){
			              	i = parseInt(i);
			              	i = i+1;
			                my_grid.append(`
			                  	<tr class="rowsasaran" data-uid="`+value.ID_SASARAN+`" data-sasaran="`+value.NAMA_SASARAN+`"data-strategi="`+value.STRATEGI_SASARAN+`" >
									<td>`+i+`</td>
									<td>`+value.NAMA_SASARAN+`</td>
									<td align="center"></td>
								</tr>
			                `);
			            });    
		            }else{
		              	my_grid.append(`
		                  	<tr class="rowsasaran">
								<td>Belum Ada Data Sasaran</td>
								<td></td>
								<td align="center"></td>
							</tr>
			            `);
		            }
		          },
		          beforeSend: function() {
		          	/*var my_grid = $("#sasaransatker");
		          	grid.html(`<div class="loader"></div>`);*/
		               
		          }
	        	});
			}
			if(eselon==3){
				$(".rowindikatorsasaran").remove();
				$(".rowindikatorprogram").remove(); 	
				$(".keuangan").show();
				$(".btn-tambahsasaran").show();
				$(".btn-ubahsasaran").show();
				$(".iks_link").hide();
				$("#iks_link2").show();
					$.ajax({
			        	type: 'POST',
			        	url: app.data.site_url + '/sasaran/get_sasasranbysatker',
			          	cache: false,
			          	data: {
			            	ID_SATKER : node,
			          	},
		          	success: function (data) {
		            	data = JSON.parse(data);
						console.log(data);
						var my_grid = $("#sasaransatker");
		            	$(".rowsasaran").remove();
		            	if(data.length>0){
				            $.each(data, function(i, value){
				              	i = parseInt(i);
				              	i = i+1;
				                my_grid.append(`
				                  	<tr class="rowsasaran" data-uid="`+value.ID_SASARAN+`" data-sasaran="`+value.NAMA_SASARAN+`"data-strategi="`+value.STRATEGI_SASARAN+`" >
										<td>`+i+`</td>
										<td>`+value.NAMA_SASARAN+`</td>
										<td align="center"></td>
									</tr>
				                `);
				            });    
		            	}else{
			              	my_grid.append(`
			                  	<tr class="rowsasaran">
									<td>Belum Ada Data Sasaran</td>
									<td></td>
									<td align="center"></td>
								</tr>
				            `);
		            	}
		          	},
			        beforeSend: function() {
			          	/*var my_grid = $("#sasaransatker");
			          	grid.html(`<div class="loader"></div>`);*/
			               
			        }
	        	});
				$(".keuangan").show();
				 app.body_mask();
				 $.ajax({
		          type: 'POST',
		          url: app.data.site_url + '/sasaran/get_sasasranbysatker',
		          cache: false,
		          data: {
		            ID_SATKER : node,
		          },
		          success: function (data) {
		              data = JSON.parse(data);
		              console.log(data);
		              app.body_unmask();
		              var my_grid = $("#sasaransatker");
		              $(".rowsasaran").remove();
		              /*$(".loader").remove();*/
		              if(data.length>0){
			              $.each(data, function(i, value){
			              	i = parseInt(i);
			              	i = i+1;
			                my_grid.append(`
			                  	<tr class="rowsasaran" data-uid="`+value.ID_SASARAN+`" data-sasaran="`+value.NAMA_SASARAN+`"data-strategi="`+value.STRATEGI_SASARAN+`" >
									<td>`+i+`</td>
									<td>`+value.NAMA_SASARAN+`</td>
									<td align="center"></td>
								</tr>
			                `);
			              });    
		              }else{
		              	my_grid.append(`
		                  	<tr class="rowsasaran">
								<td>Belum Ada Data Sasaran</td>
								<td></td>
								<td align="center"></td>
							</tr>
			            `);
		              }
		          },
		          beforeSend: function() {
		          }
	        	});
			}
			if(eselon==4){
				$(".rowindikatorprogram").remove();
				$(".rowindikatorsasaran").remove();
				$(".btn-tambahprogram").show();
				$(".btn-tambahsasaran").show();
				$(".btn-ubahsasaran").show();
				$(".btn-cetak").hide();
				$(".btn-cetak-eselon-4").show();
				$("#iks_link").hide();
				$("#iks_link2").hide();
				$("#iks_link3").show();
				$(".rowsasaran").remove();
				 app.body_mask();
				 $.ajax({
		          type: 'POST',
		          url: app.data.site_url + '/sasaran/get_sasasranbysatker',
		          cache: false,
		          data: {
		            ID_SATKER : node,
		          },
		          success: function (data) {
		              data = JSON.parse(data);
		              console.log(data);
		              app.body_unmask();
		              var my_grid = $("#sasaransatker");
		              $(".rowsasaran").remove();
		              /*$(".loader").remove();*/
		              if(data.length>0){
			              $.each(data, function(i, value){
			              	i = parseInt(i);
			              	i = i+1;
			                my_grid.append(`
			                  	<tr class="rowsasaran" data-uid="`+value.ID_SASARAN+`" data-sasaran="`+value.NAMA_SASARAN+`"data-strategi="`+value.STRATEGI_SASARAN+`" >
									<td>`+i+`</td>
									<td>`+value.NAMA_SASARAN+`</td>
									<td align="center"></td>
								</tr>
			                `);
			              });    
		              }else{
		              	my_grid.append(`
		                  	<tr class="rowsasaran">
								<td>Belum Ada Data Sasaran</td>
								<td></td>
								<td align="center"></td>
							</tr>
			            `);
		              }
		          },
		          beforeSend: function() {
		          	/*var my_grid = $("#sasaransatker");
		          	grid.html(`<div class="loader"></div>`);*/
		               
		          }
	        	});
			}
		},

		setactivesasaran:function(){
			$( "table" ).delegate( "tr", "click", function() {
			    $(this).addClass('active').siblings().removeClass('active');
			    var id = $('.rowsasaran.active').data('uid');
			    return id;
			});
		},

		getsasaranid:function(){
			var sasaranid = $('.rowsasaran.active').data('uid');
			return sasaranid;
		},

		checkEselon: function(node){
			var myarr = node.split(".");
			node = myarr.length - 1;
			return node;
		},

		simpansasaran: function(){
				$('#form-indikator').validate({
					ignore: [],
					errorPlacement: function(error, element) {
						error.insertAfter(element.parent());
					}
				});
		},

		buttonAction: function() {
			var me = this,
				params = {};

				$("button[action='cetak-pk'],a[action='cetak-pk']").on('click', function(event) {					
                    me.cetak_pk();
				});
				$("a[action='cetak-template']").on('click', function(event) {					
					params.type = 'template';
                    me.cetak_pk(params);
				});
		},

		cetak_pk: function(arguments) {
			var me = this,
				node = $("#treeunit").jstree("get_selected")[0],
				eselon = perjanjian_kinerja.checkEselon(node),
				tipe_indikator = 1;
			if (eselon == 4) {
				tipe_indikator = 3;
			}
			if (arguments && 'type' in arguments) {
				eselon = arguments.type;
			}
			window.open(app.data.site_url + "/perjanjian_kinerja/app/cetak?ID_SATKER="+node+"&eselon="+eselon+"&tipe_indikator="+tipe_indikator);
		},

		get_indikatorbysatker(arg){
			node = $("#treeunit").jstree("get_selected")[0];
			var eselon = perjanjian_kinerja.checkEselon(node);
			var tipe;
			if(eselon<3){
				tipe = 1;
			}
			if(eselon==3){
				tipe = 1;
			}
			if(eselon==4){
				tipe = 1;
			}
			$.ajax({
		          type: 'POST',
		          url: app.data.site_url + '/sasaran/get_indikatorsasaranbysatker',
		          cache: false,
		          data: {
		            ID_SATKER : arg,
		            TIPE : tipe,
		          },
		          success: function (data) {
		              data = JSON.parse(data);
		              datagrid = data.data;
		              console.log(data);
		              $(".rowindikatorsasaran").remove();
		              $(".rowformulasi").remove();
		              var my_grid = $("#indikatorsasaran");
		              /*$(".loader").remove();*/
		              app.body_unmask();
		              if(datagrid.length>0){
			              $.each(datagrid, function(i, value){
			              	i = parseInt(i);
			              	if(value.TARGET_INDIKATOR==null){
			              		value.TARGET_INDIKATOR = '0';
			              	}
			              	var total = parseInt(value.TOTAL);
			              		var target= parseInt(value.TARGET_INDIKATOR);
			              		var caption;
			              		if(total>target){
			              			caption = 'lebih';
			              		}
			              		if(total<target){
			              			caption = 'lebih';
			              		}
			              		if(total==target){
			              			caption = 'sama';
			              		}
			              		
			              	if(value.TOTAL==null){
			              		value.TOTAL = '0';
			              	}
			              	i = i+1;
			                my_grid.append(`
			                	<tr class="rowindikatorsasaran">
									<td>`+i+`</td>
									<td><a href="`+app.data.site_url+`/indikator/ubah/indikator/`+value.ID_INDIKATOR+`">`+value.NAMA_INDIKATOR+`</a></td>
									<td align="center">`+value.TARGET_INDIKATOR+`</td>
									<td align="center">`+value.TOTAL+`</td>
									<td align="center"><i class="fa fa-circle co-`+caption+`" aria-hidden="true"></td>
									<td align="center"><i class="fa fa-exclamation-triangle is_tantangan" aria-hidden="true"></i></td>
									<td align="center"><i class="fa fa-download" aria-hidden="true"></i></td>
								</tr>
			                `);
			              });    
			            }else{
			              	my_grid.append(`
			                  	<tr class="rowindikatorsasaran">
									<td colspan="7">Belum Ada Data Indikator</td>
								</tr>
				            `);
			            }
			            $('#formulasiindikator').append(`
	         				<tr class="rowformulasi">
								<td colspan="2">Rata-Rata</td>
								<td align="center">`+app.round10(data.avg_target,2)+`%</td>
								<td align="center">`+data.avg_realisasi+`%</td>
								<td colspan="3" align="center">0%</td>
							</tr>
             			`);
		          },
		          beforeSend: function() {
		          	/*var my_grid = $("#sasaransatker");
		          	grid.html(`<div class="loader"></div>`);*/
		               
		          }
	        	});
		},

		get_programsasaransatker(arg){
			var satker = $("#treeunit").jstree("get_selected")[0];

			$.ajax({
		          type: 'POST',
		          url: app.data.site_url + '/program/program/get_programsasaranbysatker',
		          cache: false,
		          data: {
		            ID_SATKER : arg,
		          },
		          success: function (data) {
		          	  app.body_unmask();
		              data = JSON.parse(data);
		              console.log(data);
		              $(".rowindikatorprogram").remove();
		              var my_grid = $("#indikatorprogram");
		              /*$(".loader").remove();*/
		              if(data.length>0){
			              $.each(data, function(i, value){
			              	console.log(value);
			              	i = parseInt(i);
			              	i = i+1;
			              	var money = value.TARGET;
			              	if(value.REALISASI==null){
			              		value.REALISASI="-";
			              	}
			                my_grid.append(`
			                	<tr class="rowindikatorprogram">
									<td>`+i+`</td>
									<td><a href="`+app.data.site_url+`/program/ubah/program/`+value.ID_PROGRAM+`">`+value.NAMA_PROGRAM+`</a></td>
									<td align="right">Rp. `+value.TARGET+`</td>
									<td align="right">`+value.REALISASI+`</td>
									<td align="center"><i class="fa fa-circle co-kurang" aria-hidden="true"></i></td>
									<td></td>
								</tr>
			                	
			                `);
			              });    
		              }else{
		              	my_grid.append(`
		                  	<tr class="rowindikatorprogram">
								<td colspan="7">Belum Ada Data Program</td>
							</tr>
			            `);
		              }

		              

		          },
		          beforeSend: function() {
		          	/*var my_grid = $("#sasaransatker");
		          	grid.html(`<div class="loader"></div>`);*/
		               
		          }
	        	});
		},
		selected: {},
		id: '',
		isLoad: false,
	};

	app.loader(perjanjian_kinerja);
});