$(document).ready(function() {
	var indikator = {
		load: {
			css: [

			],
			js: [

			],
			success: function() {
				
				if(typeof data!="undefined"){
					data = JSON.parse(data);
					console.log(data);
					app.set_form_value($("#form-ubahprogram"),data);
				}
				$('.select2').select2();
				// definisikan validasi form
				$('#form-indikator').validate({
					ignore: [],
					errorPlacement: function(error, element) {
						error.insertAfter(element.parent());
					}
				});
				$('#form-tambahprogram').validate({
					ignore: [],
					errorPlacement: function(error, element) {
						error.insertAfter(element.parent());
					}
				});
				
				$('.btn-table button').on('click', function(event) {
					$($(this).attr('target')).modal('show');
				});

				$('.btn-ubahbukti').on('click', function(event) {
					$($(this).attr('target')).modal('show');
				});

				$('.btn-table button').on('click', function(event) {
					$($(this).addClass('active'));
				});

				
				$('#chooseFile').bind('change', function () {
				  var filename = $("#chooseFile").val();
				  if (/^\s*$/.test(filename)) {
				    $(".file-upload").removeClass('active');
				    $("#noFile").text("No file chosen..."); 
				  }
				  else {
				    $(".file-upload").addClass('active');
				    $("#noFile").text(filename.replace("C:\\fakepath\\", "")); 
				  }
				});
				// event simpan indikator
				app.submit_form('#form-ubahprogram', '#btn-simpanprogram', function() {
					if ($('#form-ubahprogram').valid()) { // cek is valid
						var formData = new FormData($('#form-ubahprogram')[0]);
						$.ajax({
								url: app.data.site_url + '/program/Tambah/upd',
								method: "POST",
								data: formData,
								async: false,
								cache: false,
								contentType: false,
								processData: false,
							})
							.done(function(data) {
								var obj = $.parseJSON(data);
							
								$('#modal-notifikasi .modal-body').html(obj.msg);
								$('#modal-notifikasi').modal({
									keyboard: false,
									backdrop: 'static'
								});
							});
					}
				});

				app.submit_form('#form-tambahprogram', '#btn-tambahprogram', function() {
					if ($('#form-tambahprogram').valid()) { // cek is valid
						var formData = new FormData($('#form-tambahprogram')[0]);
						$.ajax({
								url: app.data.site_url + '/program/Tambah/add',
								method: "POST",
								data: formData,
								async: false,
								cache: false,
								contentType: false,
								processData: false,
							})
							.done(function(data) {
								var obj = $.parseJSON(data);
							
								$('#modal-notifikasi .modal-body').html(obj.msg);
								$('#modal-notifikasi').modal({
									keyboard: false,
									backdrop: 'static'
								});
							});
					}
				});
			}
		},

		selected: {},
		id: '',
		isLoad: false,
	};

	app.loader(indikator);
});