$(document).ready(function() {
	$('#wrapper').toggleClass('toggled');
	var dokumentasi = {
		cmp:{
			table_dokumentasi:'table-dokumentasi',
			modal_dokumen: 'modal-dokumen',
			filter_tahun: $("#filter-tahun"),
			form_dokument: $("#form-dokument"),
			form_dokument_id:"#form-dokument",
		},
		load: {
			css: [

			],
			js: [

			],
			success: function() {
				// action button
				dokumentasi.buttonAction(); 
				// event show/hide sidebar
				dokumentasi.treesatker();
				dokumentasi.listeners();				
				
				$('#btn-side').on('click', function(event) {
					$('#wrapper').toggleClass('toggled');
					if (!$('#wrapper').is('.toggled')) {
						$('#sidebar-wrapper div, #sidebar-wrapper label').not('#label').hide('400');
					} else {
						$('#sidebar-wrapper div, #sidebar-wrapper label').not('#label').show('400');
					}
				});

			}
		},

		treesatker: function() {
			var me = this;
			$('#treeunit')
				.on('changed.jstree', function(e, data) {
					if (typeof data.node != 'undefined') {
						$("#treeunit").jstree("get_selected")[0];
						var node = data.node.id;
						var params = {
							ID_SATKER:node,
						}	
						me.treeSelected = [];					
						me.treeSelected.push(data.node);
						me.getData(params);						
					}
				})
				.on('loaded.jstree', function(e, data) {
					// var node = (app.data.user.usergroupid == 2) ? app.data.user.satkerid : '01';

					// $("#treeunit").jstree('open_node', node);
					// $("#treeunit").jstree('select_node', node);
				})
				.jstree({
					core: {
						data: {
							url: app.data.site_url + '/master/satker/get_tree',
							dataType: 'json',
							 "data" : function (node) {                  
				                  return { id : node.id };
				              }
						}
					},
					plugins: ['json_data', 'search']
				});
		},

		buttonAction: function() {
			var me = this;

			$('button,a').on('click', function(even) {
				event.preventDefault();
                var action = $(this).attr('action');                
                switch (action) {
                    case 'upload-dokumen':
                        me.popupDokumen($(this));
                        break;                    
                }
            });
		},

		popupDokumen: function(cmp) {
			var me = this;

			var type = {
				PK_MURNI: {
					TAHUN: me.cmp.filter_tahun.val(),
					TAHUN_TEXT: me.cmp.filter_tahun.val(),
					NAMA_DOKUMEN_TEXT: "Perjanjian Dokumen",
					NAMA_DOKUMEN: "Perjanjian Dokumen",
					JENIS: "Murni",					
				}, 
				PK_PERUBAHAN:{
					TAHUN: me.cmp.filter_tahun.val(),
					TAHUN_TEXT: me.cmp.filter_tahun.val(),					
					NAMA_DOKUMEN_TEXT: "Perjanjian Dokumen",
					NAMA_DOKUMEN: "Perjanjian Dokumen",
					JENIS: "Perubahan",
				},
				LAKIP:{
					TAHUN: me.cmp.filter_tahun.val(),
					TAHUN_TEXT: me.cmp.filter_tahun.val(),					
					NAMA_DOKUMEN_TEXT: "Lakip",
					NAMA_DOKUMEN: "Lakip",
					JENIS: "Lakip",
				}
			}

			// get form document by type
			var data = me.data[cmp.data("index")],
				data_dokument = data.DOKUMEN[cmp.attr('type')];
			for(var i in type[cmp.attr('type')]){
				data_dokument[i] = type[cmp.attr('type')][i];
			}

			data_dokument.JENIS_DOKUMEN = cmp.attr('type');
			data_dokument.ID_SATKER = data.ID_SATKER;

			//clear/reset form document
			app.clear_form(me.cmp.form_dokument_id);

			// set form document
			app.set_form_value(me.cmp.form_dokument,data_dokument);			
			var files = me.cmp.form_dokument.find('.list-file'),
				item_file = `
				<a href="`+ data_dokument.URL_FILE +`" download><i class="fa fa-download"></i> Download</a><a/>
				`;
			if ("ROW_ID" in data_dokument) {
				files.removeClass('hidden');
				files.find(".input-file").html(item_file);
			}else{
				files.addClass('hidden');
			}			

			$('#'+me.cmp.modal_dokumen).modal({
				keyboard: false,
				backdrop: 'static'
			});
		},

		listeners: function() {
			var me = this,
				cmp = me.cmp;

			// event change filter tahun
			cmp.filter_tahun.on("change",function() {
				me.getData();
			});


			$(".input-file").before(
				function() {
					if ($(this).find('.file-input')) {
						var me_ = $(this);
						var element = $(this).find('.file-input');						
						element.change(function(){
							me_.find("input[type='text']").val((element.val()).split('\\').pop());
						});
						$(this).find("button.btn-choose").click(function(){
							element.click();
						});						
						
						return element;
					}
			});

			app.submit_form(me.cmp.form_dokument_id,"#btn-simpan-dokumen",function() {
				if (me.cmp.form_dokument.valid()) { // cek is valid
						app.body_mask();
						var formData = new FormData(me.cmp.form_dokument[0]);
						$.ajax({
								url: app.data.site_url + '/dokumentasi/app/save',
								method: "POST",
								data: formData,
								async: false,
								cache: false,
								contentType: false,
								processData: false,
							})
							.done(function(data) {
								var obj = $.parseJSON(data);
								app.body_mask();								
								me.getData();
								$('#'+me.cmp.modal_dokumen).modal("hide");
								$('#modal-notifikasi .modal-body').html(obj.msg);
								$('#modal-notifikasi').modal({
									keyboard: false,
									backdrop: 'static'
								});								
								
							})
							.always(function() {
								app.body_unmask();
							});
					}
				
			});
		},

		getData: function(argument) {
			var me = this;
			if (me.treeSelected.length == 1) {				
				var params = {
					ID_SATKER: me.treeSelected[0].id,
					TAHUN: me.cmp.filter_tahun.val()
				};
				app.body_mask();
				$.ajax({
					url: app.data.site_url + '/dokumentasi/app/get',
					method: "POST",
					data: params				
				})
				.done(function(result) {				
					var data = $.parseJSON(result);														
					me.data = data.data;
					me.generateData(me.data);
				})
				.always(function(){
					app.body_unmask();
				});	
			}else{
				$('#modal-warning .modal-body').html("Pilih data terlebih dahulu");
				$('#modal-warning').modal({
					keyboard: false,
					backdrop: 'static'
				});
			}
		},

		generateData: function(data) {
			var me = this,
				table = $("."+me.cmp.table_dokumentasi+' tbody');				
			table.html('');
			data.forEach(function(rec,i) {				
				// start row table dokumentasi
				var temp = `
							<tr>
								<td rowspan="2" width='45'>`+(parseInt(i)+1)+`</td>
								<td rowspan="2">`+rec.NAMA_SATKER+`</td>
								<td>PK</td>				
								<td align="center"><button data-index=`+i+` class="fa fa-file-text file-dokumen `+rec.PK_MURNI+`" action="upload-dokumen" type='PK_MURNI' ></button></td>
								<td></td>
								<td align="center"><button data-index=`+i+` class="fa fa-file-text file-dokumen `+rec.PK_PERUBAHAN+`" action="upload-dokumen" type='PK_PERUBAHAN'></button></td>
							</tr>
							<tr>																
								<td>LAKIP</td>
								<td></td>
								<td align="center"><button data-index=`+i+` class="fa fa-file-text file-dokumen `+rec.LAKIP+`" action="upload-dokumen" type='LAKIP'></button></td>
								<td></td>
							</tr>
							`;
				// end row table dokumentasi 

				table.append(temp);
			});
			me.buttonAction();

		},

		treeSelected: [],
		selected: {},
		id: '',
		data:[],
		isLoad: false,
	};

	app.loader(dokumentasi);
});