app = {};

app.startup = function(args) {
    app.loader(args);
};

app.onReady = function(args) {
    var load_js = args.load.js_second || {};

    var loaded = {};
    loaded.js = '';

    for (i = 0; i < load_js.length; i++) {
        app.load_js(load_js[i]);
        loaded.js += load_js[i] + ' ';
    }

    app.body_unmask();

    $(document).on('show.bs.modal', '.modal', function() {
        var zIndex = 1040 + (10 * $('.modal:visible').length);
        // $(this).css('z-index', zIndex);
        setTimeout(function() {
            $('.modal-backdrop').not('.modal-stack').css('z-index', zIndex - 1).addClass('modal-stack');
            $('body').css('padding-right', '0px');
        }, 0);
    });
};

app.loader = function(args) {
    var load_css = args.load.css || {};
    var load_js = args.load.js || {};


    var loaded = {};
    loaded.css = '';
    loaded.js = '';
    for (i = 0; i < load_css.length; i++) {
        app.load_css(load_css[i]);
        loaded.css += load_css[i] + ' ';
    }

    for (i = 0; i < load_js.length; i++) {
        app.load_js(load_js[i]);
        loaded.js += load_js[i] + ' ';
    }

    if (typeof args.load.success == 'function') {
        typeof args.load.success();
    }
};

app.load_js = function(url) {
    var head = document.getElementsByTagName('head')[0];
    var link = document.createElement('script');
    link.type = 'text/javascript';
    link.charset = 'UTF-8';
    link.src = url;
    head.appendChild(link);
    // document.write('<script type="text/javascript" charset="UTF-8" src="' + url + '"></script>');
};

app.load_css = function(url) {
    var head = document.getElementsByTagName('head')[0];
    var link = document.createElement('link');
    link.rel = 'stylesheet';
    link.type = 'text/css';
    link.href = url;
    link.media = 'all';
    head.appendChild(link);
    // document.write('<link href="' + url + '" rel="stylesheet">');
};

app.body_mask = function() {
    $('.loader').show();
    $('body').css('overflow', 'hidden');
};

app.body_unmask = function() {
    $('.loader').hide();
    $('body').css('overflow', 'auto');
};

app.convert_form = function(param) {
    var out = {};
    for (var i = 0; i < param.length; i++) {
        out[param[i].name] = param[i].value;
    }

    return out;
};

app.params_serialize = function(params) {
    var out = {};
    params.forEach(function(item, index, arr) {

    });

    return out;
};

app.set_form_value = function(frm, data) {
    $.each(data, function(key, value) {
        value = value || '-';
        var $ctrl = $('[name=' + key + ']', frm);
        switch ($ctrl.attr("type")) {
            case "text":
            case "hidden":
                $ctrl.val(value);
                break;
            case "radio":
            case "checkbox":
                $ctrl.each(function() {
                    if ($(this).attr('value') == value) {
                        $(this).attr("checked", value);
                    }
                });
                break;
            case "html":
                $ctrl.html(value);
            case "select":
                $(this).val(value);
            default:
                $ctrl.val(value);
        }
    });
};

app.image_exists = function(image_url) {

    var http = new XMLHttpRequest();

    http.open('HEAD', image_url, false);
    http.send();

    return http.status != 404;
};

app.clear_form = function(form) {    
    $(form).find('input[type=text], input[type=hidden], input[type=search], input[type=number], input[type=password], input[type=date], input[type=email], input[type=file], textarea, select').val('');
    $(form).find('.select2').val('').trigger('change.select2');
    $(form).find('.displayfield').html('');
    $(form).find('.input-date').val('').datepicker('update');
    $(form).find('.error').removeClass('error');
};

app.random_char = function(jml) {
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    jml = (typeof jml == 'undefined') ? 8 : jml;

    for (var i = 0; i < jml+1; i++)
        text += possible.charAt(Math.floor(Math.random() * possible.length));

    return text;
};
app.submit_form = function(form, button, callback) {
    $(form).delegate('input', 'keyup keypress', function(e) {
        if (e.keyCode === 13) {
            e.preventDefault();
            return false;
        }
    });

    $(form).delegate('input', 'keyup', function(e) {
        if (e.keyCode === 13) {
            $(button).click();
        }
    });

    $(button).on('click', function(e) {
        e.preventDefault();
        if (typeof callback == 'function') {
            callback.call(this);
        }
    });
};
app.showErrors = function(errorMessage, errormap, errorlist) {
    if (errorMessage) {
        var val = this;
        errormap.forEach(function(error, index) {
            val.settings.highlight.call(val, error.element, val.settings.errorClass, val.settings.validClass);
            val.showLabel(error.element, error.message);
        });
    } else {
        this.defaultShowErrors();
    }

};
app.fixValidFieldStyles = function($form, validator) {
    var errors = {};
    $form.find("input,select").each(function(index) {
        var name = $(this).attr("name");
        errors[name] = validator.errorsFor(name);
    });
    validator.showErrors(errors);
    var invalidFields = $form.find("." + validator.settings.errorClass);
    if (invalidFields.length) {
        invalidFields.each(function(index, field) {
            if ($(field).valid()) {
                $(field).removeClass(validator.settings.errorClass);
            }
        });
    }
};
app.round10 = function(number, precision) {
    var factor = Math.pow(10, precision),
        tempNumber = number * factor,
        roundedTempNumber = Math.round(tempNumber);
        
    return roundedTempNumber / factor;
};
app.getFileExtension = function(filename) {
    return filename.split('.').pop();
};
app.loading = '<div class="loading">' +
    '               <svg viewBox="0 0 32 32" width="32" height="32">' +
    '                   <circle id="spinner" cx="16" cy="16" r="14" fill="none"></circle>' +
    '               </svg>' +
    '           </div>';
app.get_param = function(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
};