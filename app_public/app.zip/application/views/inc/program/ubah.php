<script type="text/javascript">
	var data = '<?php echo json_encode($data) ?>';
</script>
<div class="col-sm-12">
	<!-- content -->
	<div class="container">
		<!-- header -->
		<div class="row">
			<div class="col-sm-6">
				<label>Ubah Program</label>
			</div>
			<div class="col-sm-6 text-right btn-table">
				<a href="<?php echo site_url('perjanjian_kinerja') ?>" class="btn btn-default btn-flat"><i class="fa fa-arrow-left" aria-hidden="true"></i></a>
			</div>
		</div>
		<!-- end header -->
		<!-- form indikator -->
		<div class="row kotak" id="satuan-kerja">
			<form id="form-ubahprogram" style="padding: 15px;">
				<input type="hidden" name="ID_PROGRAM" value="">
				<div class="row">
					<div class="col-sm-3">
						<label>Program</label>
					</div>
					<div class="col-sm-9">
						<div class="form-group">
							<input type="text" class="form-control" name="NAMA_PROGRAM" value="" required>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-sm-3">
						<label>Keterangan</label>
					</div>
					<div class="col-sm-9">
						<div class="form-group">
							<textarea class="form-control" name="KETERANGAN_PROGRAM" rows="3" required></textarea>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-3">
						<label>Realisasi</label>
					</div>
				</div>
				<div class="col-md-5">
					<div class="row">
						<div class="col-sm-7">
							<label>Triwulan 1</label>
						</div>
						<div class="col-sm-4">
							<div class="form-group">
								<input type="text" class="form-control" name="TRIWULAN_1" required>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-7">
							<label>Triwulan 2</label>
						</div>
						<div class="col-sm-4">
							<div class="form-group">
								<input type="text" class="form-control" name="TRIWULAN_2" required>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-7">
							<label>Triwulan 3</label>
						</div>
						<div class="col-sm-4">
							<div class="form-group">
								<input type="text" class="form-control" name="TRIWULAN_3" required>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-7">
							<label>Triwulan 4</label>
						</div>
						<div class="col-sm-4">
							<div class="form-group">
								<input type="text" class="form-control" name="TRIWULAN_4" required>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-7">
							<!-- <label>Total : 4</label> -->
						</div>
					</div>
				</div>
				</form>
			</div>
		</div>
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-6">
				<div class="row">
					<div class="col-xs-6">
						<div class="form-group">
							<button type="reset" class="btn btn-default btn-flat form-control">Batal</button>
						</div>
					</div>
					<div class="col-xs-6">
						<div class="form-group">
							<button class="btn btn-success btn-flat form-control" id="btn-simpanprogram">Simpan</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</form>
</div>
<!-- end content -->
</div>
<?php $this->load->view('inc/indikator/modal_bukti');?>
<script type="text/javascript" src="<?php echo $this->config->item('url_app') ?>js/modules/program.js"></script>