<!-- modal sasaran -->
<div class="modal fade" id="modal-tantangan">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Tambah Sasaran</h4>
            </div>
            <div class="modal-body">
                <form id="form-sasaran">
                    <input type="hidden" name="id">
                    <input type="hidden" name="ID_SATKER">
                    <div class="row">
                        <div class="col-sm-3">
                            <label>Sasaran</label>
                        </div>
                        <div class="col-sm-9">
                           <div class="form-group">
                                <select class="form-control select2" name="SATUAN_INDIKATOR" required="">
                                    <option value="1">TRIWULAN 1</option>
                                    <option value="2">TRIWULAN 2</option>
                                    <option value="3">TRIWULAN 3</option>
                                    <option value="4">TRIWULAN 4</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-3">
                            <label>Strategi Kebijakan</label>
                        </div>
                        <div class="col-sm-9">
                            <div class="form-group has-feedback">
                                <textarea class="form-control" name="strategi" required rows="4"></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                         <div class="form-group">
                            <input type="file" name="file" class="file">
                            <div class="input-group col-xs-12">
                              <span class="input-group-addon"><i class="glyphicon glyphicon-picture"></i></span>
                              <input type="text" class="form-control input-lg" disabled placeholder="Upload Image">
                              <span class="input-group-btn">
                                <button class="browse btn btn-primary input-lg" type="button"><i class="glyphicon glyphicon-search"></i> Browse</button>
                              </span>
                            </div>
                          </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer" style="padding-bottom: 0px; padding-top: 0px;">
                <div class="row">
                    <div class="col-md-6" style="padding-left: 0px; padding-right: 0px;">
                        <button type="button" class="btn btn-default btn-flat form-control" data-dismiss="modal">Batal</button>
                    </div>
                    <div class="col-md-6" style="padding-left: 0px; padding-right: 0px;">
                        <button type="button" class="btn btn-primary btn-flat form-control" id="btn-simpansasaran">Simpan</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end modal sasaran -->