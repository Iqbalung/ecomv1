<div class="col-sm-12">
	<!-- content -->
	<div class="container">
		<!-- header -->
		<div class="row">
			<div class="col-sm-6">
				<label>Tambah Indikator</label>
			</div>
			<div class="col-sm-6 text-right btn-table">
				<a href="<?php echo site_url('perjanjian_kinerja') ?>" class="btn btn-default btn-flat"><i class="fa fa-arrow-left" aria-hidden="true"></i></a>
			</div>
		</div>
		<!-- end header -->
		<!-- form indikator -->
		<div class="row kotak" id="satuan-kerja">
			<form id="form-indikator" style="padding: 15px;">
				<input type="hidden" name="ID_SASARAN" value="<?php echo $ID_SASARAN ?>">
				<div class="row">
					<div class="col-sm-3">
						<label>Indikator</label>
					</div>
					<div class="col-sm-9">
						<div class="form-group">
							<input type="text" class="form-control" name="NAMA_INDIKATOR" required>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-sm-3">
						<label>Rumus</label>
					</div>
					<div class="col-sm-9">
						<div class="form-group">
							<textarea class="form-control" name="FORMULA_INDIKATOR" rows="3" required></textarea>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-sm-3">
						<label>Target</label>
					</div>
					<div class="col-sm-1">
						<div class="form-group">
							<input type="text" class="form-control" name="TARGET_INDIKATOR" required>
						</div>
					</div>
					<div class="col-sm-2">
						<div class="form-group">
							<select class="form-control select2" name="SATUAN_INDIKATOR" required="">
								<option>%</option>
								<option>Rp.</option>
							</select>
						</div>
					</div>
				</div>
				</form>
				<div class="row">
					<div class="col-sm-6">
						<div class="row">
							<div class="col-xs-6">
								<div class="form-group">
									<button type="reset" class="btn btn-default btn-flat form-control">Batal</button>
								</div>
							</div>
							<div class="col-xs-6">
								<div class="form-group">
									<button class="btn btn-success btn-flat form-control" id="btn-simpanindikator">Simpan</button>
								</div>
							</div>
						</div>
					</div>
				</div>
			
		</div>
		<!-- end form indikator -->
	</div>
	<!-- end content -->
</div>

<script type="text/javascript" src="<?php echo $this->config->item('url_app') ?>js/modules/indikator.js"></script>