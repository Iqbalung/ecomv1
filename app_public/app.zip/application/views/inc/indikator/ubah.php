<script type="text/javascript">
	var data = '<?php echo json_encode($data) ?>';
</script>
<div class="col-sm-12">
	<!-- content -->
	<div class="container">
		<!-- header -->
		<div class="row">
			<div class="col-sm-6">
				<label>Ubah Indikator</label>
			</div>
			<div class="col-sm-6 text-right btn-table">
				<a href="<?php echo site_url('perjanjian_kinerja') ?>" class="btn btn-default btn-flat"><i class="fa fa-arrow-left" aria-hidden="true"></i></a>
			</div>
		</div>
		<!-- end header -->
		<!-- form indikator -->
		<div class="row kotak" id="satuan-kerja">
			<form id="form-ubahindikator" style="padding: 15px;">
				<input type="hidden" name="ID_INDIKATOR" value="">
				<div class="row">
					<div class="col-sm-3">
						<label>Indikator</label>
					</div>
					<div class="col-sm-9">
						<div class="form-group">
							<input type="text" class="form-control" name="NAMA_INDIKATOR" value="" required>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-sm-3">
						<label>Rumus</label>
					</div>
					<div class="col-sm-9">
						<div class="form-group">
							<textarea class="form-control" name="FORMULA_INDIKATOR" rows="3" required></textarea>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-sm-3">
						<label>Target</label>
					</div>
					<div class="col-sm-1">
						<div class="form-group">
							<input type="text" class="form-control" name="TARGET_INDIKATOR" required>
						</div>
					</div>
					<div class="col-sm-2">
						<div class="form-group">
							<select class="form-control select2" name="SATUAN_INDIKATOR" required="">
								<option>%</option>
								<option>Rp.</option>
							</select>
						</div>
					</div>
				</div>
				<div class="row">
				<div class="col-sm-3">
					<label>Realisasi</label>
				</div>
				</div>
				<div class="col-md-5">
					<div class="row">
						<div class="col-sm-7">
							<label>Triwulan 1</label>
						</div>
						<div class="col-sm-4">
							<div class="form-group">
								<input type="text" class="form-control" name="TRIWULAN_1" required>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-7">
							<label>Triwulan 2</label>
						</div>
						<div class="col-sm-4">
							<div class="form-group">
								<input type="text" class="form-control" name="TRIWULAN_2" required>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-7">
							<label>Triwulan 3</label>
						</div>
						<div class="col-sm-4">
							<div class="form-group">
								<input type="text" class="form-control" name="TRIWULAN_3" required>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-7">
							<label>Triwulan 4</label>
						</div>
						<div class="col-sm-4">
							<div class="form-group">
								<input type="text" class="form-control" name="TRIWULAN_4" required>
							</div>
						</div>
					</div>
				</div>
				</form>
				<div class="col-md-4">
					<div class="container">
					    <div class="row">
					    	<div class="col-md-5">
			                    <ul class="nav nav-tabs">
			                        <li class="active"><a href="#tab1" data-toggle="tab">Bukti Dukung</a></li>
			                        <li><a href="#tab2" data-toggle="tab">Tantangan</a></li>
			                    </ul>
			                </div>
			                <div class="col-md-2">
								<div class="col-xs-12 text-right btn-table">
									<button class="btn btn-default btn-flat tambah-bukti"  data-toggle="modal" target="#modal-bukti"><i class="fa fa-plus" aria-hidden="true"></i></button>
									<!-- <button class="btn btn-default btn-flat btn-ubahbukti" target="#modal-sasaran"><i class="fa fa-pencil" aria-hidden="true"></i></button>
									<button class="btn btn-default btn-flat"><i class="fa fa-trash" aria-hidden="true"></i></button> -->
								</div>			                	
			                </div>
					    </div>
	                    <div class="tab-content">
	                        <div class="tab-pane fade in active" id="tab1">
	                        	<br>
                        		<div class="row">
                        			<div class="col-md-6">
			                        <?php foreach ($dokumen as $key => $value) { ?>
			                        	<div class="col-sm-6">
							                <div class="info-box">
							                    <span class="info-box-icon bg-aqua">
						                    	<?php if($value['TYPE']=="jpg" || $value['TYPE']=="png"){ ?>
						                    		<img style="height: 88px;width:100px;" src="<?php echo base_url() ?>client/uploads/bukti/<?php echo $value['GENERATED_NAME'] ?>" />
						                    	<?php }else{ ?>
						                    		<i class="fa fa-envelope-o"></i>
						                    	<?php } ?>
							                    </span>
							                    <div class="info-box-content">
							                        <span class="info-box-text"><?php echo $value['KETERANGAN'] ?></span>
							                        <span class="info-box-number"><?php echo $value['GENERATED_NAME'] ?></span>
							                    </div>
							                </div>
							            </div>
			                        <?php } ?>	
			                    	</div>
	                        	</div>           	
	                        </div>
	                        <div class="tab-pane fade" id="tab2">	  	
	                        </div>
	                    </div>
				    </div>
				</div>
			</div>
		</div>
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-6">
				<div class="row">
					<div class="col-xs-6">
						<div class="form-group">
							<button type="reset" class="btn btn-default btn-flat form-control">Batal</button>
						</div>
					</div>
					<div class="col-xs-6">
						<div class="form-group">
							<button class="btn btn-success btn-flat form-control" id="btn-updindikator">Simpan</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</form>
</div>
<!-- end content -->
</div>
<?php $this->load->view('inc/indikator/modal_bukti');?>
<script type="text/javascript" src="<?php echo $this->config->item('url_app') ?>js/modules/indikator.js"></script>