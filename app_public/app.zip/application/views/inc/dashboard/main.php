<div class="row">

<div class="container-fluid">
<ul class="nav nav-pills nav-stacked col-md-2">
  <li class="active"><a href="#tab_a" data-toggle="pill">Berita</a></li>
  <li><a href="#tab_b" data-toggle="pill">Video</a></li>
  <li><a href="#tab_c" data-toggle="pill">Galery</a></li>
</ul>
<div class="tab-content col-md-10">
    <div class="tab-pane active" id="tab_a">
        <div class="row" style="margin-left: 0px; margin-right: 0px;">
        <div class="col-sm-12" style="padding-left: 0px; padding-right: 0px;">
            <!-- peringkat -->
            <div class="peringkat">
                <label>Berita <a href="<?php echo site_url('/dashboard/app/tambah_news') ?>">+</a></label> 
                <div class="body-peringkat" id="list_berita">
                    
                </div>
            </div>
            <!-- end peringkat -->
        </div>
        </div>
    </div>
        <div class="tab-pane" id="tab_b">
            <div class="row" style="margin-left: 0px; margin-right: 0px;">
        <div class="col-sm-12" style="padding-left: 0px; padding-right: 0px;">
            <!-- peringkat -->
            <div class="peringkat">
                <label>Video<a href="<?php echo site_url('/dashboard/app/tambah_video') ?>">+</a></label> 
                <div class="body-peringkat" id="list_video">
                    
                </div>
            </div>
            <!-- end peringkat -->
        </div>
        </div>
        </div>
       
        <div class="tab-pane" id="tab_c">
            <div class="row" style="margin-left: 0px; margin-right: 0px;">
        <div class="col-sm-12" style="padding-left: 0px; padding-right: 0px;">
            <!-- peringkat -->
            <div class="peringkat">
                <label>Galery<a href="<?php echo site_url('/dashboard/app/tambah_galery') ?>">+</a></label> 
                <div class="body-peringkat" id="list_galery">
                    
                </div>
            </div>
            <!-- end peringkat -->
        </div>
        </div>
        </div>
</div><!-- tab content -->
</div><!-- end of container -->

</div>

<script type="text/javascript" src="<?php echo $this->config->item('url_app') ?>js/modules/dashboard.js"></script>
<script type="text/javascript" src="<?php echo $this->config->item('url_app') ?>js/modules/news.js"></script>