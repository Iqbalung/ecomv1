<style type="text/css">
	.header-master{
		background-color: #fff;
		color: #939498;
		text-align: center;
		padding: 20px auto;
		border-top: 1px solid #CACACA;
		border-bottom: 1px solid #CACACA;
	}
	.column-master{
		
		padding: 20px auto;
		border-right: 1px solid #CACACA;
		border-left: 1px solid #CACACA;
	}
	span.max
	{
	    display: block;
	}
</style>
<?php 
$this->view("inc/master/satker/modal.php");
$this->view("inc/master/modal.php");
 ?>
<div class="col-sm-12">
	<!-- content -->
	<div class="container">
		<!-- header -->
		<div class="row">
			<div class="col-sm-6">
				<div class="row tab-control">
					<div class="col-xs-4 disable-select active" target="#master-satuan-kerja" url="satuan-kerja">Satuan Kerja</div>
					<div class="col-xs-4 disable-select" target="#tantangan" url="tantangan">Tantangan</div>
					<div class="col-xs-4 disable-select" target="#user" url="user">User</div>
				</div>
			</div>
			<div class="col-sm-6 text-right btn-table">
				<button class="btn btn-default btn-flat btn-action" id="btn-tambah" modal="#modal-satuan-kerja"  base-action="tambah-master" action="tambah-master-satuan-kerja"><i class="fa fa-plus" aria-hidden="true"></i></button>

				<button class="btn btn-default btn-flat btn-action" id="btn-ubah" base-action="ubah-master" action="ubah-master-satuan-kerja"><i class="fa fa-pencil" aria-hidden="true"></i></button>
				
				<button class="btn btn-default btn-flat btn-action" id="btn-hapus" base-action="hapus-master" action="hapus-master-satuan-kerja"><i class="fa fa-trash" aria-hidden="true"></i></button>
				
			</div>
		</div>
		<!-- end header -->

		<!-- table satuan kerja -->
		<div class="row kotak" id="master-satuan-kerja">						
				<span class="row">				
					<span class="col-md-4" align="center">Nama Satuan Kerja</span>
					<span class="col-md-2" align="center">Nama Jabatan</span>
					<span class="col-md-2" align="center">Nama Pejabat</span>
					<span class="col-md-2" align="center">NIP Pejabat</span>
					<span class="col-md-2" align="center">Pangkat Pejabat</span>
				</span>										
				<div id="tree-satuan-kerja"></div>			
		</div>
		<!-- end table satuan kerja -->

		<!-- table tantangan -->
		<div class="row kotak" id="tantangan" style="display: none; min-height: 400px;">
			<table class="table table-bordered table-striped table-hover" id="table-tantangan">
				<thead>
					<tr>
						<td align="center">No</td>
						<td>Kategori</td>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td colspan="2" align="center">Data tidak ditemukan</td>
					</tr>
				</tbody>
			</table>
		</div>
		<!-- end table tantangan -->

		<!-- table user -->
		<div class="row kotak" id="user" style="display: none;">
			<table class="table table-bordered table-striped table-hover" id="table-user">
				<thead>
					<tr>
						<td align="center">No</td>
						<td align="center">Nama User</td>
						<td align="center">Nama</td>
						<td align="center">NIP</td>
						<td align="center">Hak Akses</td>
						<td align="center">Satuan Kerja</td>
					</tr>
				</thead>
				<tbody>
					<?php for ($i=1;$i<14;$i++): ?>
						<tr>
							<td><?php echo $i ?></td>
							<td>Admin</td>
							<td>Andri Riyadi</td>
							<td>123456789</td>
							<td>Barenlitbang</td>
							<td>Pemerintah Kota Malang</td>
					<?php endfor ?>
				</tbody>
			</table>
		</div>
		<!-- end table user -->
	</div>
	<!-- end content -->
</div>

<script type="text/javascript" src="<?php echo $this->config->item('url_app') ?>js/modules/master.js"></script>