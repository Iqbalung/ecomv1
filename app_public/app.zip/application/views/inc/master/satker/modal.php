

<!-- modal tambah satker -->
<div class="modal fade" id="modal-form-master-satker">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Tambah</h4>
            </div>
            <div class="modal-body">
               <div class="row kotak" id="satuan-kerja">
				<form id="form-satker" style="padding: 15px;">

					<input type="hidden" name="ID_SATKER">
					<input type="hidden" name="ID_SATKER_PARENT">

					<div class="row">
						<div class="col-sm-3">
							<label>Satuan Kerja</label>
						</div>
						<div class="col-sm-9">
							<div class="form-group">
								<input type="text" class="form-control" name="NAMA_SATKER" required>
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-sm-3">
							<label>Nama Jabatan</label>
						</div>
						<div class="col-sm-9">
							<div class="form-group">
								<input type="text" class="form-control" name="NAMAJABATAN_SATKER" required>
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-sm-3">
							<label>Pejabat</label>
						</div>
					</div>

					<div class="row">
						<div class="col-sm-3">
							<label>Nama</label>
						</div>
						<div class="col-sm-9">
							<div class="form-group">
								<input type="text" class="form-control" name="NAMA_PEJABAT_SATKER" required>
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-sm-3">
							<label>NIP</label>
						</div>
						<div class="col-sm-9">
							<div class="form-group">
								<input type="text" class="form-control" name="NIP_PEJABAT_SATKER" required>
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-sm-3">
							<label>Pangkat Pejabat</label>
						</div>
						<div class="col-sm-9">
							<div class="form-group">
								<input type="text" class="form-control" name="PANGKAT_PEJABAT_SATKER" required>
							</div>
						</div>
					</div>					
				</form>
			</div>
            </div>
            <div class="modal-footer" style="padding-bottom: 0px; padding-top: 0px;">
                <div class="row">
                    <div class="col-md-6" style="padding-left: 0px; padding-right: 0px;">
                        <button type="button" class="btn btn-default btn-flat form-control" data-dismiss="modal">Batal</button>
                    </div>
                    <div class="col-md-6" style="padding-left: 0px; padding-right: 0px;">
                        <button type="button" class="btn btn-primary btn-flat form-control" id="btn-simpan">Simpan</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end modal tambah satker -->