<!-- modal tantangan -->
<div class="modal fade" id="modal-tantangan">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Tambah</h4>
            </div>
            <div class="modal-body">
				<form id="form-tantangan">
					<input type="hidden" class="form-control" name="ID_TANTANGAN">
					
					<div class="row">
						<div class="col-sm-3">
							<label>Nama Tantangan</label>
						</div>
						<div class="col-sm-9">
							<div class="form-group">
								<input type="text" class="form-control" name="NAMA_TANTANGAN" required="">
							</div>
						</div>
					</div>					
				</form>
            </div>
            <div class="modal-footer" style="padding-bottom: 0px; padding-top: 0px;">
                <div class="row">
                    <div class="col-md-6" style="padding-left: 0px; padding-right: 0px;">
                        <button type="button" class="btn btn-default btn-flat form-control" data-dismiss="modal">Batal</button>
                    </div>
                    <div class="col-md-6" style="padding-left: 0px; padding-right: 0px;">
                        <button type="button" class="btn btn-primary btn-flat form-control" id="btn-simpan">Simpan</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end modal tantangan -->

<!-- modal user -->
<div class="modal fade" id="modal-user">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Tambah</h4>
            </div>
            <div class="modal-body">
				<form id="form-user">
					<input type="hidden" class="form-control" name="USERID">
					
					<div class="row">
						<div class="col-sm-3">
							<label>Nama User</label>
						</div>
						<div class="col-sm-9">
							<div class="form-group">
								<input type="text" class="form-control" name="USERLOGIN" required="">
							</div>
						</div>
					</div>
					
					<div class="row">
						<div class="col-sm-3">
							<label>Nama</label>
						</div>
						<div class="col-sm-9">
							<div class="form-group">
								<input type="text" class="form-control" name="USERNAMA" required="">
							</div>
						</div>
					</div>
					
					<div class="row">
						<div class="col-sm-3">
							<label>NIP</label>
						</div>
						<div class="col-sm-9">
							<div class="form-group">
								<input type="text" class="form-control number" name="NIP" required="">
							</div>
						</div>
					</div>
					
					<div class="row">
						<div class="col-sm-3">
							<label>Hak Akses</label>
						</div>
						<div class="col-sm-9">
							<div class="form-group">
								<select class="form-control select2" class="form-control" name="USERGROUPID" required="" style="width: 100%">
									
								</select>
							</div>
						</div>
					</div>
					
					<div class="row">
						<div class="col-sm-3">
							<label>Satuan Kerja</label>
						</div>
						<div class="col-sm-9">
							<div class="form-group">
								<select class="form-control select2" class="form-control" name="SATKER_ID" required="" style="width: 100%">
									
								</select>
							</div>
						</div>
					</div>
				</form>
            </div>
            <div class="modal-footer" style="padding-bottom: 0px; padding-top: 0px;">
                <div class="row">
                    <div class="col-md-6" style="padding-left: 0px; padding-right: 0px;">
                        <button type="button" class="btn btn-default btn-flat form-control" data-dismiss="modal">Batal</button>
                    </div>
                    <div class="col-md-6" style="padding-left: 0px; padding-right: 0px;">
                        <button type="button" class="btn btn-primary btn-flat form-control" id="btn-simpan">Simpan</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end modal user -->