<!-- modal sasaran -->
<div class="modal fade" id="modal-dokumen" >
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Upload Dokumen</h4>
            </div>
            <div class="modal-body">
                <form id="form-dokument" class="form-horizontal">
                    <input type="hidden" name="ROW_ID">
                    <input type="hidden" name="DOKUMEN_UID">
                    <input type="hidden" name="ID_SATKER">
                    <input type="hidden" name="JENIS_DOKUMEN">
                    <input type="hidden" name="NAMA_DOKUMEN">
                    <input type="hidden" name="GENERATED_NAME">
                    <input type="hidden" name="TAHUN">

                    <div class="form-group">
                        <label class="col-sm-4">Tahun</label>
                        <div class="col-sm-8">
                          <span type="html" name="TAHUN_TEXT" class="text-green displayfield">2017</span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-4">Jenis</label>
                        <div class="col-sm-8">
                          <span type="html" name="JENIS" class="text-green displayfield">Murni</span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-4">Nama Dokumen</label>
                        <div class="col-sm-8">
                          <span type="html" name="NAMA_DOKUMEN_TEXT" class="text-green displayfield">Perjanjian Kerja</span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-4">Lampiran</label>
                        <div class="col-sm-6">
                            <div class="input-group input-file" >
                                <input type="file" class="file-input hidden" name="LAMPIRAN" hidden="hidden">
                                <input type="text" class="form-control"  readonly placeholder='Pilih dokumen...' />
                                <span class="input-group-btn">
                                    <button class="btn btn-default btn-choose" type="button"><span class="fa fa-upload"></span></button>
                                </span>                                
                            </div>
                        </div>
                    </div>
                    <div class="form-group list-file hidden">
                        <label class="col-sm-4"></label>
                        <div class="col-sm-6">
                            <div class="input-group input-file" >
                                <a href=""><i class="fa fa-download"></i> Download</a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer" style="padding-bottom: 0px; padding-top: 0px;">
                <div class="row">
                    <div class="col-md-6" style="padding-left: 0px; padding-right: 0px;">
                        <button type="button" class="btn btn-default btn-flat form-control" data-dismiss="modal">Batal</button>
                    </div>
                    <div class="col-md-6" style="padding-left: 0px; padding-right: 0px;">
                        <button type="button" class="btn btn-primary btn-flat form-control" id="btn-simpan-dokumen">Simpan</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end modal sasaran -->