<style type="text/css">
	#sidebar-wrapper.fixed {
	    position: fixed;
	    height: 100vh;
	    margin-top: -15px;
	    overflow-x: scroll;
	}

	.text-green{
		color: #4BB871;
	}

	/*start table dokumentasi*/
	.table-dokumentasi tr,td{
		cursor: default !important;
	}
	.table-dokumentasi thead th,
	.table-dokumentasi tbody td
	{
		background-color: #fff;
	}
	
	.table-dokumentasi tbody tr:nth-child(even) td
	{
		background-color: #F7F9F8;
	}

	.file-dokumen{
		background-color: transparent;
		border-style: none;
		padding: none;
		cursor: pointer;
		color: #B6B7BB;
		font-size: 20px;
	}

	.file-dokumen.active{
		color: #4BB871;
	}

	.cell-dokumen{
		width: 60px;
		text-align: center;
	}

	/*end table dokumentasi*/
</style>
<div class="row">
	<div id="wrapper">
		<!-- Sidebar -->
		<div id="sidebar-wrapper" class="fixed">
			<div id="label">
				<label>Organisasi Perangkat Daerah</label> <i class="fa fa-angle-left" id="btn-side" aria-hidden="true"></i>
			</div>
			<div id="treeunit"></div>
		</div>
		<!-- /#sidebar-wrapper -->
		<!-- Page Content -->
		<div id="page-content-wrapper">
			<div class="row" style="margin-left: 0px; margin-right: 0px;">
				<div class="col-sm-12">
					<!-- header content -->
					<div class="row header" style="padding: 10px 0;">
						<div class="col-sm-4 pull-right text-right">
							<div class="row">								
								<div class="col-sm-6 col-sm-push-6">
									<select class="form-control" id="filter-tahun">
										<?php 
										$date = Date("Y");
										for ($i=-1; $i < 2; $i++) { 
										?>
										<option value="<?php echo $date+$i; ?>"><?php echo $date+$i; ?></option>
										<?php
										}
										 ?>
									</select>
								</div>
							</div>
						</div>
					</div>
					<!-- end header content -->
					<!-- body content -->
					<div class="row body">
						
						<!-- start table dokumentasi -->
						<table class="table table-dokumentasi table-responsive table-bordered table-striped">
							<thead>
								<tr>
									<th width="45">No</th>
									<th>Organisasi Perangkat Daerah</th>
									<th>Dokumen</th>
									<th class="cell-dokumen">Murni</th>
									<th class="cell-dokumen"></th>
									<th class="cell-dokumen">Perubahan</th>
								</tr>
							</thead>
							<tbody>

								<!-- start row table dokumentasi -->
								
								<!-- end row table dokumentasi -->

							</tbody>
						</table>
						<!-- end table dokumentasi -->

					</div>
					<!-- end content -->
				</div>
			</div>
		</div>
		<!-- /#page-content-wrapper -->
	</div>
	<!-- /#wrapper -->
</div>
<?php $this->view("inc/dokumentasi/modal_dokumen"); ?>
<script type="text/javascript" src="<?php echo $this->config->item('url_app') ?>js/modules/dokumentasi.js"></script>