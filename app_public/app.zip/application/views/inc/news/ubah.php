<script type="text/javascript">
	var id = '<?php echo $id; ?>';
	$.ajax({
		          type: 'POST',
		          url: app.data.site_url + '/dashboard/app/edit/'+id,
		          cache: false,
		          data: {

		          },
		          success: function (data) {
		            var data = JSON.parse(data);		               
		            app.set_form_value($("#form-ubahnews"),data[0]);
		          },
		          beforeSend: function() {
		          	/*var my_grid = $("#sasaransatker");
		          	grid.html(`<div class="loader"></div>`);*/
		               
		          }
	        	});
</script>
<div class="col-sm-12">
	<!-- content -->
	<div class="container">
		<!-- header -->
		<div class="row">
			<div class="col-sm-6">
				<label>Ubah</label>
			</div>
			<div class="col-sm-6 text-right btn-table">
				<a href="<?php echo site_url('dashboard') ?>" class="btn btn-default btn-flat"><i class="fa fa-arrow-left" aria-hidden="true"></i></a>
			</div>
		</div>
		<!-- end header -->
		<!-- form indikator -->
		<div class="row kotak" id="satuan-kerja">
			<form id="form-ubahnews" style="padding: 15px;">
				<div class="row">
					<input type="hidden" class="form-control" name="id" required>
					<input type="hidden" class="form-control" name="type" required>
					<div class="col-sm-3">
						<label>Judul</label>
					</div>
					<div class="col-sm-9">
						<div class="form-group">
							<input type="text" class="form-control" name="judul" required>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-sm-3">
						<label>Isi</label>
					</div>
					<div class="col-sm-9">
						<div class="form-group">
							<textarea class="form-control" name="isi" rows="30" required></textarea>
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="col-sm-3">
						<label>Gambar</label>
					</div>
					<div class="col-sm-9">
	                    <div class="file-upload">
	                      <div class="file-select">
	                        <div class="file-select-button" id="fileName">Pilih FIle</div>
	                        <div class="file-select-name" id="noFile">Tidak ada yang dipilih</div> 
	                        <input type="file" name="userfile" id="chooseFile">
	                      </div>
	                    </div>
                	</div>
                </div>
                <br><br>
				</form>
				<div class="row">
					<center>
						
					<div class="col-sm-6">
						<div class="row">
							<div class="col-xs-6">
								<div class="form-group">
									<button type="reset" class="btn btn-default btn-flat form-control">Batal</button>
								</div>
							</div>
							<div class="col-xs-6">
								<div class="form-group">
									<button class="btn btn-success btn-flat form-control" id="btn-updnews">Simpan</button>
								</div>
							</div>
						</div>
					</div>
					</center>
				</div>
			
		</div>
		<!-- end form indikator -->
	</div>
	<!-- end content -->
</div>

<script type="text/javascript" src="<?php echo $this->config->item('url_app') ?>js/modules/news.js"></script>