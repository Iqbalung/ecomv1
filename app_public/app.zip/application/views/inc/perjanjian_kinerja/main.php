<style type="text/css">
	#sidebar-wrapper.fixed {
    position: fixed;
    height: 100vh;
    margin-top: -15px;
    overflow-x: scroll;
}
</style>
<div class="row">
	<div id="wrapper">
		<!-- Sidebar -->
		<div id="sidebar-wrapper" class="fixed">
			<div id="label">
				<label>Organisasi Perangkat Daerah</label> <i class="fa fa-angle-left" id="btn-side" aria-hidden="true"></i>
			</div>
			<div id="treeunit"></div>
		</div>
		<!-- /#sidebar-wrapper -->
		<!-- Page Content -->
		<div id="page-content-wrapper">
			<div class="row" style="margin-left: 0px; margin-right: 0px;">
				<div class="col-sm-12">
					<!-- header content -->
					<div class="row header">
						<div class="col-sm-12 text-right keuangan">
							<!-- <div id="jml">88</div>
							<div id="nilai">Rp. 5.000.000.000,-</div>
							 -->
							<button class="btn btn-default btn-flat btn-cetak" action="cetak-pk"><i class="fa fa-print" aria-hidden="true"></i></button>

							<div class="btn-group btn-cetak-eselon-4">
							  <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
							     <i class="fa fa-print"></i> <span class="caret"></span>
							  </button>
							  <ul class="dropdown-menu" role="menu" style="margin-right: 20px;">
							    <li><a href="#" action="cetak-pk">Perjanjian Kerja</a></li>
							    <li><a href="#" action="cetak-template">Template</a></li>							    
							  </ul>
							</div>
						</div>
					</div>
					<!-- end header content -->
					<!-- body content -->
					<div class="row body">
						<div class="col-md-6" style="padding-left: 30px;padding-right: 30px;">
							<!-- table sasaran -->
							<div class="row">
								<div class="col-xs-6">
									<label class="label-table">Sasaran</label>
								</div>
								<div class="col-xs-6 text-right btn-table">
									<button class="btn btn-default btn-tambahsasaran btn-flat" target="#modal-sasaran"><i class="fa fa-plus" aria-hidden="true"></i></button>
									<button class="btn btn-default btn-flat btn-ubahsasaran" target="#modal-sasaran"><i class="fa fa-pencil" aria-hidden="true"></i></button>
									<button class="btn btn-default btn-hapussasaran btn-flat"><i class="fa fa-trash" aria-hidden="true"></i></button>
								</div>
							</div>
							<div class="row kotak">
								<div class="table-responsive">
									<table class="table table-bordered table-striped table-hover">
										<tbody id="sasaransatker">
												<!-- <tr>
													<td></td>
													<td>Meningkatnya kualitas aksesibilitas dan pemerataan pelayanan pendidikan</td>
													<td align="center">95</td>
												</tr> -->
												
										</tbody>
									</table>
								</div>
							</div>
							<!-- end table sasaran -->
						</div>
						<div class="col-md-6" style="padding-left: 30px; padding-right: 30px;">
							<!-- table indikator -->
							<div class="row">
								<div class="col-xs-6">
									<label class="label-table">Indikator <!-- Kinerja Sasaran --></label>
								</div>
								<div class="col-xs-6 text-right btn-table">
									<a href="<?php echo site_url('program/tambah/program/') ?>" id="iks_link" class="btn btn-default btn-flat"><i class="fa fa-plus" aria-hidden="true"></i></a>
									<button id="iks_link2"  target="#modal-pilihprogram" class="btn btn-default btn-flat"><i class="fa fa-plus" aria-hidden="true"></i></button>
									<button id="iks_link3"  target="#modal-kegiatan" class="btn btn-default btn-flat"><i class="fa fa-plus" aria-hidden="true"></i></button>
									<!-- <button class="btn btn-default btn-flat"><i class="fa fa-pencil" aria-hidden="true"></i></button>
									<button class="btn btn-default btn-flat"><i class="fa fa-trash" aria-hidden="true"></i></button> -->
								</div>
							</div>
							<div class="row kotak">
								<div class="table-responsive">
									<table class="table table-bordered table-hover" id="table-indikator">
										<thead>
											<tr>
												<td>No</td>
												<td>Indikator</td>
												<td>Target</td>
												<td>Realisasi</td>
												<td>Capaian</td>
												<td>Tantangan</td>
												<td>Ket</td>
											</tr>
										</thead>
										<tbody id="indikatorsasaran">
											<!-- 
											<?php for ($i=1;$i<4;$i++): ?>
												<tr>
													<td><?php echo $i ?>.</td>
													<td><a href="">Angka Partisipasi Kasar (APK) SD/MI</a></td>
													<td align="center">90%</td>
													<td align="center">92%</td>
													<td align="center"><i class="fa fa-circle co-lebih" aria-hidden="true"></i></td>
													<td align="center"><i class="fa fa-exclamation-triangle is_tantangan" aria-hidden="true"></i></td>
													<td align="center"><i class="fa fa-download" aria-hidden="true"></i></td>
												</tr>
											<?php endfor ?> -->
										</tbody>
										<tfoot id="formulasiindikator">
											
										</tfoot>
									</table>
								</div>
							</div>
							<div class="keterangan text-right">
								<i class="fa fa-circle co-lebih" aria-hidden="true"></i> Melebihi Target
								<i class="fa fa-circle co-sesuai" aria-hidden="true"></i> Sesuai Target
								<i class="fa fa-circle co-kurang" aria-hidden="true"></i> Kurang dari Target
							</div>
							<!-- end table indikator -->
							<!-- table program -->
							<div class="row">
								<div class="col-xs-6">
									<label class="label-table">Program</label>
								</div>
								<div class="col-xs-6 text-right btn-table">
									<a href="#" id="ikp_link" class="btn btn-default btn-flat btn-tambahprogram"><i class="fa fa-plus" aria-hidden="true"></i></a>
									<a class="btn btn-default btn-flat btn-ubahprogram"><i class="fa fa-pencil" aria-hidden="true"></i></a>
									<button class="btn btn-default btn-flat btn-hapusprogram"><i class="fa fa-trash" aria-hidden="true"></i></button>
								</div>
							</div>
							<div class="row kotak">
								<div class="table-responsive">
									<table class="table table-bordered table-hover" id="table-indikator">
										<thead>
											<tr>
												<td>No</td>
												<td>Program</td>
												<td>Target (Rp)</td>
												<td>Realisasi (Rp)</td>
												<td>Capaian</td>
												<td>Keterangan</td>
											</tr>
										</thead>
										<tbody id="indikatorprogram">
											<!-- <?php for ($i=1;$i<2;$i++): ?>
												<tr>
													<td><?php echo $i ?>.</td>
													<td><a href="">Peningkatan kapasitas serta, profesionalisme guru dan tenaga kependidikan</a></td>
													<td align="right">10.000.000</td>
													<td align="right">10.000.000</td>
													<td align="center"><i class="fa fa-circle co-kurang" aria-hidden="true"></i></td>
													<td>Dinas Pendidikan</td>
												</tr>
											<?php endfor ?> -->
										</tbody>
									</table>
								</div>
							</div>
							<div class="keterangan text-right">
								<i class="fa fa-circle co-lebih" aria-hidden="true"></i> Melebihi Target
								<i class="fa fa-circle co-sesuai" aria-hidden="true"></i> Sesuai Target
								<i class="fa fa-circle co-kurang" aria-hidden="true"></i> Kurang dari Target
							</div>
							<!-- end table program -->
						</div>
					</div>
					<!-- end content -->
				</div>
			</div>
		</div>
		<!-- /#page-content-wrapper -->
	</div>
	<!-- /#wrapper -->
</div>
<?php $this->load->view('inc/perjanjian_kinerja/modal'); ?>
<?php $this->load->view('inc/perjanjian_kinerja/modal_pilihprogram'); ?>
<?php $this->load->view('inc/perjanjian_kinerja/modal_pilihkegiatan'); ?>
<script type="text/javascript" src="<?php echo $this->config->item('url_app') ?>js/modules/perjanjian_kinerja.js"></script>