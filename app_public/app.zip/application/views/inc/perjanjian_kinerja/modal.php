<!-- modal sasaran -->
<div class="modal fade" id="modal-sasaran">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Tambah Sasaran</h4>
            </div>
            <div class="modal-body">
                <form id="form-sasaran">
                    <input type="hidden" name="id">
                    <input type="hidden" name="ID_SATKER">
                    <div class="row">
                        <div class="col-sm-3">
                            <label>Sasaran</label>
                        </div>
                        <div class="col-sm-9">
                            <div class="form-group has-feedback">
                                <textarea class="form-control" name="sasaran" required rows="4"></textarea>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-3">
                            <label>Strategi Kebijakan</label>
                        </div>
                        <div class="col-sm-9">
                            <div class="form-group has-feedback">
                                <textarea class="form-control" name="strategi" required rows="4"></textarea>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer" style="padding-bottom: 0px; padding-top: 0px;">
                <div class="row">
                    <div class="col-md-6" style="padding-left: 0px; padding-right: 0px;">
                        <button type="button" class="btn btn-default btn-flat form-control" data-dismiss="modal">Batal</button>
                    </div>
                    <div class="col-md-6" style="padding-left: 0px; padding-right: 0px;">
                        <button type="button" class="btn btn-primary btn-flat form-control" id="btn-simpansasaran">Simpan</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end modal sasaran -->