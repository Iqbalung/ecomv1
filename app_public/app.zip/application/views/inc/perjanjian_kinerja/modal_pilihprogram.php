<!-- modal sasaran -->
<div class="modal fade" id="modal-pilihprogram">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Pilih Indikator Sasaran Dari Eselon 2</h4>
            </div>
            <div class="modal-body">
                <form id="form-pilihnindikator">
                    <input type="hidden" name="id">
                    <input type="hidden" name="ID_SASARAN">
                    <input type="hidden" name="ID_SATKER">
                    <table class="table table-bordered table-hover" id="table-indikator">
                        <thead>
                            <tr>
                                <td>No</td>
                                <td>Indikator</td>
                                <td>Target</td>
                                <td>Realisasi</td>
                                <td>Capaian</td>
                                <td>Tantangan</td>
                                <td>Ket</td>
                            </tr>
                        </thead>
                        <tbody id="daftarprogram"></tbody>
                    </table>
                </form>
            </div>
            <div class="modal-footer" style="padding-bottom: 0px; padding-top: 0px;">
                <div class="row">
                    <div class="col-md-6" style="padding-left: 0px; padding-right: 0px;">
                        <button type="button" class="btn btn-default btn-flat form-control" data-dismiss="modal">Batal</button>
                    </div>
                    <div class="col-md-6" style="padding-left: 0px; padding-right: 0px;">
                        <button type="button" class="btn btn-primary btn-flat form-control" id="btn-simpanindikator">Simpan</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end modal sasaran -->