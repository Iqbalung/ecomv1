<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $this->config->item('app_name').' - '.$this->config->item('client_name') ?></title>
    <link rel="shortcut icon" href="<?php echo $this->config->item('client_logo') ?>" type="image/x-icon" />
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="<?php echo $this->config->item('url_bootstrap') ?>css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $this->config->item('url_bootstrap') ?>css/bootstrap-treeview.css">
    <link rel="stylesheet" href="<?php echo $this->config->item('url_bootstrap') ?>dist/css/skins/skin-dumas.css">

    <link rel="stylesheet" type="text/css" href="<?php echo $this->config->item('url_css') ?>jquery.orgchart.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $this->config->item('url_plugins') ?>datepicker/datepicker3.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $this->config->item('url_bootstrap') ?>js/themes/default/style.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $this->config->item('url_plugins') ?>datatables/css/dataTables.bootstrap.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $this->config->item('url_plugins') ?>datatables/extensions/Responsive/css/dataTables.responsive.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $this->config->item('url_plugins') ?>select2/select2.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $this->config->item('url_bootstrap') ?>dist/css/AdminLTE.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $this->config->item('url_app') ?>css/simple-sidebar.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $this->config->item('url_app') ?>css/app.css">

    <script src="<?php echo $this->config->item('url_plugins').'jQuery/jquery-3.1.0.min.js' ?>"></script>
    <script src="<?php echo $this->config->item('url_bootstrap').'js/bootstrap-treeview.js' ?>"></script>
    <script src="<?php echo $this->config->item('url_bootstrap').'js/jstree.min.js' ?>"></script>
    <script src="<?php echo $this->config->item('url_bootstrap').'js/jstreegrid.js' ?>"></script>
    <script src="<?php echo $this->config->item('url_plugins') ?>input-mask/inputmask/inputmask.js"></script>
    <script src="<?php echo $this->config->item('url_plugins') ?>input-mask/inputmask/inputmask.extensions.js"></script>
    <script src="<?php echo $this->config->item('url_plugins') ?>input-mask/inputmask/inputmask.numeric.extensions.js"></script>
    <script src="<?php echo $this->config->item('url_plugins') ?>input-mask/inputmask/inputmask.date.extensions.js"></script>
    <script src="<?php echo $this->config->item('url_plugins') ?>input-mask/inputmask/inputmask.phone.extensions.js"></script>
    <script src="<?php echo $this->config->item('url_plugins') ?>input-mask/inputmask/jquery.inputmask.js"></script>
    <script src="<?php echo $this->config->item('url_plugins') ?>input-mask/inputmask/phone-codes/phone.js"></script>
    <script src="<?php echo $this->config->item('url_plugins') ?>input-mask/inputmask/phone-codes/phone-be.js"></script>
    <script src="<?php echo $this->config->item('url_plugins') ?>input-mask/inputmask/phone-codes/phone-ru.js"></script>
    <script src="<?php echo $this->config->item('url_app') ?>js/startup.js"></script>
    <style type="text/css">
      .loader {
        position: fixed;
        left: 0px;
        top: 0px;
        width: 100%;
        height: 100%;
        z-index: 9999;
        background: url('<?php echo $this->config->item('url_images') ?>page-loader.gif') 50% 50% no-repeat;
      }
      .progress-bar.animate {
         width: 100%;
      }
      @keyframes progress {
    from { background-position:  0px; }
    to   { background-position: 40px; }
}
 
.progress-bar-animated {
    animation: progress 1s linear infinite;
}
    </style>
    <script type="text/javascript">
      app.data = <?php echo json_encode($data_app) ?>;

      app.startup(app.data);

      $(document).ready(function() {
        app.body_unmask();

        $('.select2').select2();

        $('.input-date').datepicker({
          format: 'dd/mm/yyyy',
          language: "id",
          autoclose: true
        });

        $('.currency').inputmask("numeric", {
            radixPoint: ".",
            groupSeparator: ",",
            digits: 2,
            autoGroup: true,
            prefix: '',
            rightAlign: false,
        });

        $('.number').inputmask("numeric", {
            radixPoint: "",
            groupSeparator: "",
            digits: 2,
            autoGroup: true,
            prefix: '',
            rightAlign: false,
        });

        $('#form-ubah-password').validate({
          rules: {
            password2: {
              equalTo: '#passwordbaru'
            }
          }
        });

        $('#btn-ubah-password').on('click', function() {
          app.clear_form($('#form-ubah-password'));
          $('#form-ubah-password').validate().resetForm();

          $('#modal-ubah-password').modal({
            keyboard: false,
            backdrop: 'static'
          });
        });

        $('#modal-ubah-password #button-ubah').on('click', function() {
          if ($('#form-ubah-password').valid()) {
            var form = $('#form-ubah-password').serializeArray(),
                params = app.convert_form(form);

            app.body_mask();
            $.ajax({
                url: app.data.base_url + '/index.php/login/upd_password',
                method: 'POST',
                data: params,
              })
              .done(function(data) {
                app.body_unmask();
                var obj = jQuery.parseJSON(data);

                $('#modal-ubah-password').modal('hide');

                $('#modal-notifikasi .modal-body').html(obj.msg);
                $('#modal-notifikasi').modal({
                  keyboard: false,
                  backdrop: 'static'
                });
              });
          }
        });
      });
    </script>
  </head>
  <?php 
    if ($this->session->userdata('logged_in')) {
      $login = 'style="display:none;"';
      $logout = '';
    }
    else {
      $login = '';
      $logout = 'style="display:none;"';
    }
   ?>
  <!-- ADD THE CLASS layout-top-nav TO REMOVE THE SIDEBAR. -->
	<div class="loader"></div>
  	<div id="place_notif"></div>
  <?php $this->load->view('main-inc/modal') ?>
  <body class="hold-transition skin-blue layout-top-nav" style="background: #EEEFEF !important; margin-top: 60px;">
  	<header class="main-header">
  		<nav class="navbar navbar-default navbar-fixed-top" style="box-shadow: 0px 1px 10px rgba(0,0,0,0.3);">
		  <div class="container-fluid">
		    <!-- Brand and toggle get grouped for better mobile display -->
		    <div class="navbar-header">
		      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
		        <span class="sr-only">Toggle navigation</span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		      </button>
		      <a href="<?php echo site_url('') ?>"><div class="navbar-brand hidden-xs logo"></div></a>
		      <a style="margin-left:60px; position: relative; bottom: 10px;" href="<?php echo site_url(); ?>" class="navbar-brand hidden-xs"><?php echo $this->config->item('app_longname') ?> <br> <strong style="font-size: 16px;"><?php echo $this->config->item('client_long') ?></strong></a>
		      <a href="<?php echo site_url(); ?>" class="navbar-brand hidden-sm hidden-md hidden-lg"><?php echo $this->config->item('app_name') ?></a>
		    </div>

		    <!-- Collect the nav links, forms, and other content for toggling -->
		    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
		      <ul class="nav navbar-nav navbar-right nav-login">
            <li class="dropdown">
              <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-haspopup="true" aria-expanded="true"><span class="text-success"><b>Admin Sistem</b></span></a>
                <ul class="dropdown-menu">
                  <li><a style="background-color:#3b434e;"><span style="font-size: 25px;color:white"><?php echo $this->session->userdata('fullname'); ?></span></a></li>
                  <li><a  href="<?php echo base_url() ?>index.php/Login/logout" data-toggle="modal">Log Out</a></li>
                </ul>
              </li>
		      </ul>
		    </div><!-- /.navbar-collapse -->
		  </div><!-- /.container-fluid -->
		</nav>
  	</header>
    <!-- Modal -->
<div class="modal fade" id="barimportdata" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="myModalLabel"><i class="fa fa-clock-o"></i> Mohon Tunggu</h4>
      </div>
      <div class="modal-body center-block">
        <p>Mohon Tunggu Sedang Melakukan Importdata RKPD</p>
        <div class="progress">
          <div class="progress">
            <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%">
            </div>
          </div>
        </div>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

  <script type="text/javascript">
    $('#barimportdata').on('shown.bs.modal', function () {
      $.ajax({
        type: 'POST',
        url: app.data.site_url + '/importdata/importdatarkpd',
        cache: false,
        data: {},
        success: function (data) {
            data = JSON.parse(data);
            if(data.success=="true"){
              $('#barimportdata').modal('hide');
            }
        },
        beforeSend: function() {
          /*var my_grid = $("#sasaransatker");
          grid.html(`<div class="loader"></div>`);*/
        }
      });
    
    
  })
  </script>