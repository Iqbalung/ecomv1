  <script type="text/javascript" src="<?php echo $this->config->item('url_plugins') ?>datatables/jquery.dataTables.min.js"></script>
	<script type="text/javascript" src="<?php echo $this->config->item('url_plugins') ?>datatables/dataTables.bootstrap.min.js"></script>
  <script type="text/javascript" src="<?php echo $this->config->item('url_plugins') ?>datatables/extensions/Select/js/dataTables.select.min.js"></script>
	<script type="text/javascript" src="<?php echo $this->config->item('url_plugins') ?>datatables/extensions/Responsive/js/dataTables.responsive.min.js"></script>
	<script type="text/javascript" src="<?php echo $this->config->item('url_plugins') ?>select2/select2.min.js"></script>
	<script type="text/javascript" src="<?php echo $this->config->item('url_plugins') ?>datepicker/bootstrap-datepicker.js"></script>
	<script type="text/javascript" src="<?php echo $this->config->item('url_plugins') ?>datepicker/locales/bootstrap-datepicker.id.js"></script>
	<script type="text/javascript" src="<?php echo $this->config->item('url_plugins') ?>JQuery-validation/dist/jquery.validate.js"></script>
    <script type="text/javascript" src="<?php echo $this->config->item('url_plugins') ?>JQuery-validation/dist/localization/messages_id.js"></script>
      <link rel="stylesheet" type="text/css" href="<?php echo $this->config->item('url_plugins') ?>JQuery-validation/css/cmxform.css">
    <script type="text/javascript">
        $(document).ready(function(){
            // console.log(app.data);
            app.onReady(app.data);
          });
    </script>
  </body>
</html>