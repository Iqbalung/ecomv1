
      <script type="text/javascript" src="<?php echo $this->config->item('url_plugins') ?>JQuery-validation/dist/jquery.validate.js"></script>
      <script type="text/javascript" src="<?php echo $this->config->item('url_plugins') ?>JQuery-validation/dist/localization/messages_id.js"></script>
      <link rel="stylesheet" type="text/css" href="<?php echo $this->config->item('url_plugins') ?>JQuery-validation/css/cmxform.css">