<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tambah extends MY_Controller {

	public function __construct()
	{
		parent::__construct();
			$this->load->model(array('M_program','M_log'));
	}

	public function program($arg)
	{
		$data = array(
			'ID_SASARAN' => $arg,
			'data_app' => $this->get_data_app()
		);
		
		$this->template->display('inc/program/tambah', $data);
	}

	

	public function add(){
		$params = array(
			'ID_SASARAN' => ifunsetempty($_POST,'ID_SASARAN',''),
			'NAMA_PROGRAM' => ifunsetempty($_POST,'NAMA_PROGRAM',''),
			'SATUAN' => "Rp.",
			'TRIWULAN_1' => ifunsetempty($_POST,'TRIWULAN_1',''),
			'TRIWULAN_2' => ifunsetempty($_POST,'TRIWULAN_2',''),
			'TRIWULAN_3' => ifunsetempty($_POST,'TRIWULAN_3',''),
			'TRIWULAN_4' => ifunsetempty($_POST,'TRIWULAN_4',''),
			'TAHUN' => $this->session->userdata('tahun'),
			'SATUAN' => "Rp.",
			'ID_PROGRAM' => $this->gen_uuid(),
			'TARGET' => ifunsetempty($_POST,'TARGET',''),
			'IDJENISANGGARAN' => $this->session->userdata('jenis'),
			'TIPE' => "2",
			'TAHUN' =>  $this->session->userdata('tahun'),
		);
		$res = $this->M_program->add($params);
		if($res){
			$out = array(
							'success' => true,
							'msg' => 'Berhasil Memperbaharui',
				);
		}else{
			$out = array(
						'success' => false,
						'msg' => 'Gagal Memperbaharui',
			);
		}
		echo json_encode($out);
	} 

	public function upd(){
		$params = array(
			'ID_SASARAN' => ifunsetempty($_POST,'ID_SASARAN',''),
			'NAMA_PROGRAM' => ifunsetempty($_POST,'NAMA_PROGRAM',''),
			'SATUAN' => "Rp.",
			'TRIWULAN_1' => ifunsetempty($_POST,'TRIWULAN_1',''),
			'TRIWULAN_2' => ifunsetempty($_POST,'TRIWULAN_2',''),
			'TRIWULAN_3' => ifunsetempty($_POST,'TRIWULAN_3',''),
			'TRIWULAN_4' => ifunsetempty($_POST,'TRIWULAN_4',''),
			'TAHUN' => $this->session->userdata('tahun'),
			'SATUAN' => "Rp.",
			'ID_PROGRAM' => ifunsetempty($_POST,'ID_PROGRAM',''),
			'TARGET' => ifunsetempty($_POST,'TARGET',''),
			'IDJENISANGGARAN' => $this->session->userdata('jenis'),
			'TIPE' => "2",
			'TAHUN' =>  $this->session->userdata('tahun'),
		);
		$res = $this->M_program->upd($params);
		if($res){
			$out = array(
							'success' => true,
							'msg' => 'Berhasil Memperbaharui',
				);
		}else{
			$out = array(
						'success' => false,
						'msg' => 'Gagal Memperbaharui',
			);
		}
		echo json_encode($out);
	}



	function gen_uuid() {
	    return sprintf( '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
	        // 32 bits for "time_low"
	        mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ),

	        // 16 bits for "time_mid"
	        mt_rand( 0, 0xffff ),

	        // 16 bits for "time_hi_and_version",
	        // four most significant bits holds version number 4
	        mt_rand( 0, 0x0fff ) | 0x4000,

	        // 16 bits, 8 bits for "clk_seq_hi_res",
	        // 8 bits for "clk_seq_low",
	        // two most significant bits holds zero and one for variant DCE1.1
	        mt_rand( 0, 0x3fff ) | 0x8000,

	        // 48 bits for "node"
	        mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff )
	    );
	}
}

/* End of file Tambah.php */
/* Location: ./application/controllers/indikator/Tambah.php */