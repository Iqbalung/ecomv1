<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Program extends MY_Controller {

	public function __construct()
	{
		parent::__construct();
			$this->load->model(array('M_indikatorsasaran','M_log','M_programsasaran','M_dokumen','M_program'));
	}


	public function get($arg)
	{
		$params = array(
			'ID_SASARAN' => $arg, 
		);
		$res =  $this->M_programsasaran->get_programsasaranbyid($params)->result_array();
		$dokumen = $this->M_dokumen->get($params['ID_PROGRAM'])->result_array();
		$data = array(
			'data' => $res[0],
			'dokumen' => $dokumen,
			'data_app' => $this->get_data_app()
		);
		$this->template->display('inc/program/ubah', $data);
	}

	function get_programbykode(){
		$params = array(
			'ID_SASARAN' => ifunsetempty($_POST,'ID_SASARAN',''),
			'TAHUN' => $this->session->userdata('tahun'),
			'TIPE' => "2"
		);
		print_r($params);
		exit;
		$res = $this->M_indikatorsasaran->get_indikatorsasaran($params)->result_array();
		if(!empty($res)){
	      	$prog = array();
	      	foreach ($res as $key => $value) {
	      		$prog[] = "'" .$value['KODE_PROGRAM']."'";
	      	}
	      	$prog = implode(",", $prog);
	      	//AMBIL INDIKATORN DARI PROGRAM (KODE_PROGRAM)
	      	$res =  $this->M_program->get_programbykode($prog)->result_array(); 

	      	echo json_encode($res);
		}else{
			$arr = array();
			echo json_encode($arr);
		}
		/*$avg_target 	= $this->M_indikatorsasaran->get_avgindikatorsasaran($params)->row();
		$avg_realisasi	= $this->M_indikatorsasaran->get_avgindikatorsasaran($params)->row();
		$avg_tantangan	= $this->M_indikatorsasaran->get_avgindikatorsasaran($params)->row();
		$data = array(
			'data' => $res,
			'avg_target' => array_sum($res['TARGET_INDIKATOR']/count($res)),
			'avg_realisasi' => array_sum($res['TARGET_INDIKATOR']/count($res)),
			'avg_tantangan' => array_sum($res['TARGET_INDIKATOR']/count($res)),
		);*/
	}

	public function get_indikatorprogram(){
		//AMBIL SASARAN YANG DIPILIH ATASANYA 
		$params = array(
      		'ID_SATKER' 		=> ifunsetempty($_POST,'ID_SATKER',''),
      	);
		$parent = explode(".", $params['ID_SATKER']);
		$parent = $parent[0].".".$parent[1].".";
      	$params = array(
      		'ID_SATKER' 		=> $parent,
      		'TAHUN' 		=> $this->session->userdata('tahun'),
      	);
      	$res =  $this->M_program->get_indikatorprogram($params)->result_array();

      	echo json_encode($res);
	}

	public function simpan()
	{
		$params = array(
      		'ID_PROGRAM' 		=> ifunsetempty($_POST,'ID_PROGRAM',''),
      		'KETERANGAN_PROGRAM'=> ifunsetempty($_POST,'KETERANGAN_PROGRAM',''),
      		'TRIWULAN_1' 		=> ifunsetempty($_POST,'TRIWULAN_1',''),
      		'TRIWULAN_2' 		=> ifunsetempty($_POST,'TRIWULAN_2',''),
      		'TRIWULAN_3' 		=> ifunsetempty($_POST,'TRIWULAN_3',''),
      		'TRIWULAN_4' 		=> ifunsetempty($_POST,'TRIWULAN_4',''),
      		'TIPE' 				=> 1
      	);
		$res =  $this->M_programsasaran->upd($params);
		if($res){
			$out = array(
						'success' => true,
						'msg' => 'Berhasil Memperbaharui',
			);
		}	
		echo json_encode($out);
	}


	function get_programsasaran(){
		$params = array(
			'ID_SASARAN' => ifunsetempty($_POST,'ID_SASARAN',''),
			'TAHUN' => $this->session->userdata('tahun'),
		);
		$data = array();
		$res =  $this->M_programsasaran->get_programsasaran($params)->result_array();
		foreach ($res as $key => $value) {
			$value['TARGET'] = number_format($value['TARGET'], 0 , '' , '.' );
			$data[] = $value;
			
		}
		echo json_encode($data);
	}

	function get_programsasaranbysatker(){
		$params = array(
			'ID_SATKER' => ifunsetempty($_POST,'ID_SATKER',''),
			'TAHUN' => $this->session->userdata('tahun'),
		);
		$data = array();
		$res =  $this->M_programsasaran->get_programsasaranbysatker($params)->result_array();
		foreach ($res as $key => $value) {
			$value['TARGET'] = number_format($value['TARGET'], 0 , '' , '.' );
			$data[] = $value;
			
		}
		echo json_encode($data);
	}

}

/* End of file Tambah.php */
/* Location: ./application/controllers/indikator/Tambah.php */