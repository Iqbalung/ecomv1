<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ubah extends MY_Controller {

	public function __construct()
	{
		parent::__construct();
			$this->load->model(array('M_indikatorsasaran','M_log','M_programsasaran','M_dokumen'));
	}

	public function program($arg)
	{
		$params = array(
			'ID_PROGRAM' => $arg, 
		);
		$res =  $this->M_programsasaran->get_programsasaranbyid($params)->result_array();
		$dokumen = $this->M_dokumen->get($params['ID_PROGRAM'])->result_array();
		$data = array(
			'data' => $res[0],
			'dokumen' => $dokumen,
			'data_app' => $this->get_data_app()
		);
		$this->template->display('inc/program/ubah', $data);
	}
}

/* End of file Tambah.php */
/* Location: ./application/controllers/indikator/Tambah.php */