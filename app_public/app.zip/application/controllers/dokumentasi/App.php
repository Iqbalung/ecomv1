<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class App extends MY_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model("M_dokumentasi");
		$this->type = array("PK_MURNI","PK_PERUBAHAN","LAKIP");
		$this->path = array(
							"PK_MURNI" => "perjanjian_kerja",
							"PK_PERUBAHAN" => "perjanjian_kerja",
							"LAKIP" => "lakip"
						);
	}

	public function index()
	{
		$data = array(
			'data_app' => $this->get_data_app()
		);
		
		$this->template->display('inc/dokumentasi/main', $data);
	}

	public function get()
	{
		$params = array(
			'ID_SATKER' => ifunsetempty($_POST,"ID_SATKER",""),
			'TAHUN' => ifunsetempty($_POST,"TAHUN",""),
		);

		$res = $this->M_dokumentasi->get($params);
		$data = array();
		foreach ($res->result_array() as $key => $value) {

			$path = "";
			if (isset($this->path[$value["JENIS_DOKUMEN"]])) {
				$path = $this->path[$value["JENIS_DOKUMEN"]];
			}
			

			if (isset($data[$value["ID_SATKER"]])) {
				if (in_array($value["JENIS_DOKUMEN"], $this->type)) {			
					$value["URL_FILE"] = $this->config->item("url_client_uploads")."".$path."/".ifunsetempty($value,"GENERATED_NAME","");
					$data[$value["ID_SATKER"]]["DOKUMEN"][$value["JENIS_DOKUMEN"]] = (object) $value;
					$data[$value["ID_SATKER"]][$value["JENIS_DOKUMEN"]] = 'active';
				}	
			}else{	
				$dokumen = array();
				$temp = array(
					"ID_SATKER" => $value["ID_SATKER"],
					"NAMA_SATKER" => $value["NAMA_SATKER"]
				);
				foreach ($this->type as $type) {					
					$dokumen[$type] = (object) array();
					$temp[$type] = '';
				}		
				if (in_array($value["JENIS_DOKUMEN"], $this->type)) {							
					$value["URL_FILE"] = $this->config->item("url_client_uploads")."/". $path ."/".ifunsetempty($value,"GENERATED_NAME","");
					$dokumen[$value["JENIS_DOKUMEN"]] = (object) $value;
					$temp[$value["JENIS_DOKUMEN"]] = 'active';
				}
				$temp["DOKUMEN"] = $dokumen;
				$data[$value["ID_SATKER"]] = $temp;
			}
		}
		$data_map = array();
		foreach ($data as $key => $value) {
			$data_map[] = $value;
		}
		
		if($res){
			$out = array(
				'success' => true,
				'data' => $data_map,
				'msg' => 'Get data berhasil',
			);
		}else{
			$out = array(
				'success' => false,
				'msg' => 'Get data gagal',
			);
		}

		echo json_encode($out);
	}

	public function save()
	{
		$params = array(
			"ROW_ID" => ifunsetempty($_POST,"ROW_ID",""),
			"ID_SATKER" => ifunsetempty($_POST,"ID_SATKER",""),
			"NAMA_DOKUMEN" => ifunsetempty($_POST,"NAMA_DOKUMEN",""),
			"JENIS_DOKUMEN" => ifunsetempty($_POST,"JENIS_DOKUMEN",""),
			"TAHUN" => ifunsetempty($_POST,"TAHUN","")
		);

		$res = false;

		if (empty($params["ROW_ID"])) {			
			$params["ROW_ID"] = $this->_gen_uuid();
			$res = $this->M_dokumentasi->add($params);
		}else{

			$res = $this->M_dokumentasi->upd($params);
		}

		if ($res) {		
			$params["DOKUMEN_UID"] = ifunsetempty($_POST,"DOKUMEN_UID","");
			$res_doc = $this->_save_document($params);
		}

		if ($res && $res_doc["success"]) {			
			$out = $this->_respon(($res && $res_doc["success"]),"create");
		}else{
			$out = $res_doc;
		}

		echo json_encode($out);
	}

	protected function _save_document($argument = array())
	{
		$this->load->model("M_dokumen");

		$dokumen_uid = ifunsetempty($argument,'DOKUMEN_UID','');
		$params = array(
			'PARENT_UID' => ifunsetempty($argument,'ROW_ID',''),
			'KETERANGAN' => ifunsetempty($argument,'JENIS_DOKUMEN',''),
			'JUDUL' => ifunsetempty($argument,'JENIS_DOKUMEN',''),
			'DOKUMEN_UID' => $this->_gen_uuid(),
		);

		$path = "";
		if (isset($this->path[$params["KETERANGAN"]])) {
			$path = $this->path[$params["KETERANGAN"]];
		}

		$config = array(
            'upload_path'   => $this->config->item("path_client_upload")."/". $path,  
            'allowed_types' => '*'              
		);
		
	    if(isset($_FILES["LAMPIRAN"]) && !empty($_FILES["LAMPIRAN"]['name'])){

	    	$name = $_FILES["LAMPIRAN"]['name'];
			$filename = md5($name.time());
			$config['file_name'] = $filename;	
	    	$this->load->library('upload', $config);

	    	if (! $this->upload->do_upload("LAMPIRAN")) {

		        $out = array(
                	'success' => false,                	
                	'msg' => $name.' - '.strip_tags($this->upload->display_errors())
                ); 

		    } else { 

		        $data = $this->upload->data();
		      	$params['GENERATED_NAME'] = $data['file_name'];
		      	$params['SIZE'] = $data['file_size'];		

		      	if (!empty($dokumen_uid)) {      				

		      		$last_file = ifunsetempty($argument,"GENERATED_NAME","");

		      		if (!empty($last_file)) {		      			
			      		$params_delete = array(
			      			"DOKUMEN_UID" => $dokumen_uid
			      		);
		      			unlink($this->config->item("path_client_upload") ."/". $path ."/". $last_file);
						$this->M_dokumen->del($params_delete);
		      		}

      			}

				$res = $this->M_dokumen->add($params);
      			$out = $this->_respon($res);
      			
		    } 
		}		
		return $out;
	}

}

/* End of file App.php */
/* Location: ./application/controllers/dokumentasi/App.php */