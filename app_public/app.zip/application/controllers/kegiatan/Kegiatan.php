<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kegiatan extends MY_Controller {

	public function __construct()
	{
		parent::__construct();
			$this->load->model(array('M_indikatorsasaran','M_indikatorkegiatan','M_log','M_kegiatan','M_programsasaran','M_dokumen','M_program'));
	}


	public function get_indikatorkegiatan(){
		//Saran
		$params = array(
			'ID_SATKER' => ifunsetempty($_POST,'ID_SATKER',''),
			'TAHUN' =>  $this->session->userdata('tahun'),
		);
		$parent = explode(".", $params['ID_SATKER']);
		$parent = $parent[0].".".$parent[1].".".$parent[2].".";
      	$params = array(
      		'ID_SATKER' 	=> $parent,
      	);
      	//ALGORITMA 
      	//1. AMBIL ATASAN
      	//2. SELECT DARI INDIKATOR KEGIATAN DARI PROGRAM PUNYA ATASAN

      	$res =  $this->M_indikatorkegiatan->get_indikatorkegiatan($params)->result_array(); 
      	echo json_encode($res);

	}	

	public function addmultiselect(){
		$status = array();
		$params = array(
			'ID_INDIKATOR' => ifunsetempty($_POST,'ID_INDIKATOR',''),
			'ID_SASARAN' => ifunsetempty($_POST,'ID_SASARAN',''),
			'ID_SATKER' => ifunsetempty($_POST,'ID_SATKER',''),
		);	
		
		/*foreach ($params['ID_INDIKATOR'] as $key => $value) {
			$arg['ID_INDIKATOR'] = $value;
			$res = $this->M_indikatorkegiatan->get_indikatorbyid($arg['ID_INDIKATOR'])->result_array();
			$par['ID_KEGIATAN'] = $res[0]['ID_SASARAN'];
			$program = $res[0]['ID_SASARAN'];
			$res[$key]['TIPE'] = "1";
			$res[$key]['TAHUN'] = $this->session->userdata('tahun');
			$res[$key]['ID_INDIKATOR'] = $this->gen_uuid();
			//Tambah Indikator Kegiatan
			$res = $this->M_indikatorsasaran->add($res[$key]);
			if($res){
				$status['status_indikator'] = "Berhasil Menambah Indikator";
				$status['data_es4'] = $res[$key];
			}
			$kegiatan = $this->M_kegiatan->get_kegiatanbyid($par['ID_KEGIATAN'])->result_array();
			foreach ($kegiatan as $keys => $values) {
				$values['ID_KEGIATAN'] = $this->gen_uuid();
				$values['ID_SATKER'] = $params['ID_SATKER'];
				$add = $this->M_kegiatan->add($values);
				if($add){
					$status['kegiatan'] = "Berhasil Menambah";
					$status['data_es4_keg'] = $values;
				}
			}
		}*/

		foreach ($params['ID_INDIKATOR'] as $key => $value) {
			$arg['ID_INDIKATOR'] = $value;
			$res = $this->M_indikatorkegiatan->get_indikatorbyid($arg['ID_INDIKATOR'])->result_array();
			$par['ID_KEGIATAN'] = $res[0]['ID_SASARAN'];
			$kegiatan = $this->M_kegiatan->get_kegiatanbyid($par['ID_KEGIATAN'])->result_array();
			foreach ($kegiatan as $keys => $values) {
				$values['ID_KEGIATAN'] = $this->gen_uuid();
				$values['ID_SATKER'] = $params['ID_SATKER'];
				$add = $this->M_kegiatan->add($values);
				if($add){
					$status['kegiatan'] = "Berhasil Menambah";
					$status['data_es4_keg'] = $values;
				}
				
				$res[$key]['TIPE'] = "1";
				$res[$key]['ID_SASARAN'] = $values['ID_KEGIATAN'];
				$res[$key]['TAHUN'] = $this->session->userdata('tahun');
				$res[$key]['ID_INDIKATOR'] = $this->gen_uuid();
				//Tambah Indikator 
				$indikator = $this->M_indikatorsasaran->add($res[$key]);
				if($indikator){
					$status['status_indikator'] = "Berhasil Menambah Indikator";
					$status['data_es4'] = $res[$key];
				}
			}
		}

		if($res){
			$out = array(
							'success' => true,
							'msg' => 'Berhasil Memperbaharui',
							'status' => $status
				);
		}else{
			$out = array(
						'success' => false,
						'msg' => 'Gagal Memperbaharui',
			);
		}
		echo json_encode($out);
	}

	function gen_uuid() {
	    return sprintf( '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
	        // 32 bits for "time_low"
	        mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ),

	        // 16 bits for "time_mid"
	        mt_rand( 0, 0xffff ),

	        // 16 bits for "time_hi_and_version",
	        // four most significant bits holds version number 4
	        mt_rand( 0, 0x0fff ) | 0x4000,

	        // 16 bits, 8 bits for "clk_seq_hi_res",
	        // 8 bits for "clk_seq_low",
	        // two most significant bits holds zero and one for variant DCE1.1
	        mt_rand( 0, 0x3fff ) | 0x8000,

	        // 48 bits for "node"
	        mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff )
	    );
	}

}

/* End of file Tambah.php */
/* Location: ./application/controllers/indikator/Tambah.php */