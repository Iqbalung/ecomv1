<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ubah extends MY_Controller {

	public function __construct()
	{
		parent::__construct();
			$this->load->model(array('M_indikatorsasaran','M_log','M_indikatorsasaran','M_dokumen'));
	}

	public function indikator($arg)
	{

		$params = array(
			'ID_INDIKATOR' => $arg, 
		);

		$res =  $this->M_indikatorsasaran->get_indikatorsasaranbyid($params)->result_array();
		$dokumen = $this->M_dokumen->get($params['ID_INDIKATOR'])->result_array();
		$data = array(
			'data' => $res[0],
			'dokumen' => $dokumen,
			'data_app' => $this->get_data_app()
		);
		$this->template->display('inc/indikator/ubah', $data);
	} 

	public function simpan()
	{

		$params = array(
      		'KODE_INDIKATORSASARAN' => ifunsetempty($_POST,'KODE_INDIKATORSASARAN',''),
      		'ID_INDIKATOR' 	=> ifunsetempty($_POST,'ID_INDIKATOR',''),
      		'NAMA_INDIKATOR' 		=> ifunsetempty($_POST,'NAMA_INDIKATOR',''),
      		'RKPDID' 				=> ifunsetempty($_POST,'RKPDID',''),
      		'FORMULA_INDIKATOR' 	=> ifunsetempty($_POST,'FORMULA_INDIKATOR',''),
      		'TARGET_INDIKATOR' 		=> ifunsetempty($_POST,'TARGET_INDIKATOR',''),
      		'RKPDID_SASARAN' 		=> ifunsetempty($_POST,'RKPDID_SASARAN',''),
      		'TRIWULAN_1' 		=> ifunsetempty($_POST,'TRIWULAN_1',''),
      		'TRIWULAN_2' 		=> ifunsetempty($_POST,'TRIWULAN_2',''),
      		'TRIWULAN_3' 		=> ifunsetempty($_POST,'TRIWULAN_3',''),
      		'TRIWULAN_4' 		=> ifunsetempty($_POST,'TRIWULAN_4',''),
      		'TIPE' 				=> 1
      	);
		$res =  $this->M_indikatorsasaran->upd($params);
		if($res){
			$out = array(
						'success' => true,
						'msg' => 'Berhasil Memperbaharui',
			);
		}	
		echo json_encode($out);
	} 
}

/* End of file Tambah.php */
/* Location: ./application/controllers/indikator/Tambah.php */