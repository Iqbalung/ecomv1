<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tambah extends MY_Controller {

	public function __construct()
	{
		parent::__construct();
			$this->load->model(array('M_indikatorsasaran','M_indikatorkegiatan','M_log','M_program','M_kegiatan'));
	}

	public function indikator($arg)
	{
		$data = array(
			'ID_SASARAN' => $arg,
			'data_app' => $this->get_data_app()
		);
		
		$this->template->display('inc/indikator/tambah', $data);
	}

	public function add(){
		$params = array(
			'ID_SASARAN' => ifunsetempty($_POST,'ID_SASARAN',''),
			'NAMA_INDIKATOR' => ifunsetempty($_POST,'NAMA_INDIKATOR',''),
			'FORMULA_INDIKATOR' => ifunsetempty($_POST,'FORMULA_INDIKATOR',''),
			'TARGET_INDIKATOR' => ifunsetempty($_POST,'TARGET_INDIKATOR',''),
			'SATUAN_INDIKATOR' => ifunsetempty($_POST,'SATUAN_INDIKATOR',''),
			'TIPE' => 2,
			'TAHUN' =>  $this->session->userdata('tahun'),
		);	
		$res = $this->M_indikatorsasaran->add($params);
		if($res){
			$out = array(
							'success' => true,
							'msg' => 'Berhasil Memperbaharui',
				);
		}else{
			$out = array(
						'success' => false,
						'msg' => 'Gagal Memperbaharui',
			);
		}
		echo json_encode($out);
	}

	public function add_eselon1(){
		$params = array(
			'ID_SASARAN' => ifunsetempty($_POST,'ID_SASARAN',''),
			'NAMA_INDIKATOR' => ifunsetempty($_POST,'NAMA_INDIKATOR',''),
			'FORMULA_INDIKATOR' => ifunsetempty($_POST,'FORMULA_INDIKATOR',''),
			'TARGET_INDIKATOR' => ifunsetempty($_POST,'TARGET_INDIKATOR',''),
			'SATUAN_INDIKATOR' => ifunsetempty($_POST,'SATUAN_INDIKATOR',''),
			'TAHUN' =>  $this->session->userdata('tahun'),
			'TIPE' => 1,
		);
		$res = $this->M_indikatorsasaran->add($params);
		if($res){
			$out = array(
							'success' => true,
							'msg' => 'Berhasil Memperbaharui',
				);
		}else{
			$out = array(
						'success' => false,
						'msg' => 'Gagal Memperbaharui',
			);
		}
		echo json_encode($out);
	} 


	public function addmultiselect(){
		//TAMBAH INDIKATOR PROGRAM
		$params = array(
			'ID_INDIKATOR' => ifunsetempty($_POST,'ID_INDIKATOR',''),
			'ID_SASARAN' => ifunsetempty($_POST,'ID_SASARAN',''),
			'ID_SATKER' => ifunsetempty($_POST,'ID_SATKER',''),
		);
		//tAMBAH INDIKATOR SASARAN
		//Masukan Indikator Kegiatan


		/*
		--AMBIL ID_PROGRAMNYA
		SELECT * FROM SAKIP_INDIKATOR_SASARAN WHERE TIPE = '2'
		SELECT * FROM SAKIP_PROGRAM WHERE ID_PROGRAM = '4C084490-0597-430F-8EC2-4EB64817EE4D'

		--AMBIL KEGIATAN
		SELECT * FROM SAKIP_KEGIATAN WHERE ID_PROGRAM = '4C084490-0597-430F-8EC2-4EB64817EE4D'

		--AMBIL SAKIP INDIKATOR KEGIATAN
		SELECT * FROM SAKIP_INDIKATOR_SASARAN WHERE ID_SASARAN = 'A29CCCD0-FA09-47C4-8813-8EFC16F7BB2F'
		*/
		foreach ($params['ID_INDIKATOR'] as $key => $value) {
			$arg['ID_INDIKATOR'] = $value;
			//ambil indikator program
			//AMBIL ID_PROGRAMNYA
		
		}

		foreach ($params['ID_INDIKATOR'] as $key => $value) {
			$arg['ID_INDIKATOR'] = $value;
			//ambil program
			//Ambil Indikator
			$status = array();
			$res = $this->M_indikatorsasaran->get_indikatorprogrambyid($arg)->result_array();
			$par['ID_PROGRAM'] = $res[0]['ID_SASARAN'];
			$program = $this->M_program->get_programbyid($par)->result_array();
			$pro['ID_SASARAN']	= ifunsetempty($_POST,'ID_SASARAN','');
			$pro['KODE_PROGRAM']= $program[0]['KODE_PROGRAM'];
			$pro['TAHUN'] 		= $program[0]['TAHUN'];
			$pro['TARGET'] 		= $program[0]['TARGET'];
			$pro['ID_PROGRAM']	= $this->gen_uuid();
			$pro['TRIWULAN_1']	= $program[0]['TRIWULAN_1'];
			$pro['ID_SATKER']	= $params['ID_SATKER'];
			$pro['TRIWULAN_2']	= $program[0]['TRIWULAN_2'];
			$pro['TRIWULAN_3']	= $program[0]['TRIWULAN_3'];
			$pro['TRIWULAN_4']	= $program[0]['TRIWULAN_4'];
			$pro['TOTAL']		= $program[0]['TOTAL'];
			$pro['SATUAN'] 		= $program[0]['SATUAN'];
			$pro['DATECREATED'] = $program[0]['DATECREATED'];
			$pro['IDJENISANGGARAN'] = $program[0]['IDJENISANGGARAN'];
			$pro['NAMA_PROGRAM'] = $program[0]['NAMA_PROGRAM'];
			$pro['ID_SATKER'] = $params['ID_SATKER'];
			$pro['KETERANGAN_PROGRAM'] = $program[0]['KETERANGAN_PROGRAM'];
			$pro['TIPE'] = $program[0]['TIPE'];
			$check =  $this->M_program->checkbysasaran($pro['NAMA_PROGRAM'])->num_rows();
			/*if($check<1){*/
				$add = $this->M_program->add($pro);
				$kegiatan = $this->M_kegiatan->get_kegiatanbyprogram($res[0]['ID_SASARAN'])->result_array();
				if(!empty($kegiatan)){
					foreach ($kegiatan as $keys => $values) {
						//ambil kegiatan
						$values['ID_SATKER'] = $params['ID_SATKER'];
						$values['ID_KEGIATAN'] = $this->gen_uuid();
						$values['ID_PROGRAM'] = $pro['ID_PROGRAM'];
						$addkegiatan = $this->M_kegiatan->add($values);
						if($addkegiatan){
							$status['kegiatan'] = "berhasil Menambah Kegiatan";
						}
						$indikatorkegiatan = $this->M_indikatorkegiatan->get_indikatorbyid($kegiatan[$keys]['ID_KEGIATAN'])->result_array();
						foreach ($indikatorkegiatan as $ind => $val) {
							echo "x";
							$val['ID_INDIKATOR'] = $this->gen_uuid();
							$val['TIPE'] = '3';
							$val['ID_SASARAN'] = $values['ID_KEGIATAN'];
							$val['NAMA_INDIKATOR'] = $val['NAMA_INDIKATOR'];
							$addindikatorkeg = $this->M_indikatorkegiatan->add($val);
							if($addindikatorkeg){
								$status['indikatorkegiatan'] = "Berhasil Menambah Indikator Kegiatan";
							}
						}
					}
				/*}*/
			}
			$res = $this->M_indikatorsasaran->get_indikatorsasaranbyid($arg)->result_array();
			$res[$key]['ID_SASARAN'] = $params['ID_SASARAN'];
			$res[$key]['TIPE'] = "1";
			$res[$key]['TAHUN'] = $this->session->userdata('tahun');
			$res[$key]['ID_INDIKATOR'] = $this->gen_uuid();
			$res = $this->M_indikatorsasaran->add($res[$key]);
			if($res){
				$status['indikatorsasaranbaru'] = "Berhasil Menambah Indikator Sasaran Baru";
			}
		}
		if($res){
			$out = array(
							'success' => true,
							'msg' => 'Berhasil Memperbaharui',
							'laporan' => $status,
				);
		}else{
			$out = array(
						'success' => false,
						'msg' => 'Gagal Memperbaharui',
			);
		}
		echo json_encode($out);
	}

	function gen_uuid() {
	    return sprintf( '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
	        // 32 bits for "time_low"
	        mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ),

	        // 16 bits for "time_mid"
	        mt_rand( 0, 0xffff ),

	        // 16 bits for "time_hi_and_version",
	        // four most significant bits holds version number 4
	        mt_rand( 0, 0x0fff ) | 0x4000,

	        // 16 bits, 8 bits for "clk_seq_hi_res",
	        // 8 bits for "clk_seq_low",
	        // two most significant bits holds zero and one for variant DCE1.1
	        mt_rand( 0, 0x3fff ) | 0x8000,

	        // 48 bits for "node"
	        mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff )
	    );
	}
}

/* End of file Tambah.php */
/* Location: ./application/controllers/indikator/Tambah.php */