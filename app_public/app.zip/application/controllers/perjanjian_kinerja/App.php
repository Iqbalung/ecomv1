R<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class App extends MY_Controller {

	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		$data = array(
			'data_app' => $this->get_data_app()
		);
		
		$this->template->display('inc/perjanjian_kinerja/main', $data);
	}

	public function cetak()
	{		
		$this->load->model(array("M_satker","M_sasaran","M_indikatorsasaran","M_programsasaran","M_program"));
		$params = array(
			"ID_SATKER" => ifunsetempty($_GET,"ID_SATKER","")
		);
		$eselon = ifunsetempty($_GET,"eselon",'');
		$type = ifunsetempty($_GET,"tipe_indikator",'');
		if($eselon=="3" || $eselon=="4" ){
			$type = "1";
			$eselon = "2";
		}
		$this->load->library("template_cetak");
		$res_satker = $this->M_satker->get_byid($params);
		$data_satker = array();
		if ($res_satker->num_rows() == 1) {
			$data_satker = $res_satker->row_array();
		}		

		$res_atasan = $this->M_satker->get_parent($params);
		
		$data_atasan = array();
		if ($res_atasan->num_rows() == 1) {
			$data_atasan = $res_atasan->row_array();
		}

		$params_sasaran = array(
			'ID_SATKER' => $params['ID_SATKER'],
			'TAHUN_SASARAN' => $this->session->userdata('tahun'),
			'TIPE' => $eselon,
		);
		$data_ss = array();
		$data_program = array();
		$data_sasaran = $this->M_sasaran->get($params_sasaran)->result_array();
		if ($eselon == '1' || $eselon == '2') {
			if ($eselon == '1'){
				$template = $this->config->item("path_client_tpl")."/perjanjian_kerja/eselonI.docx";
				$output_file_name = "PERJANJIAN KINERJA TAHUN ".$this->session->userdata('tahun')." - ".$data_satker["NAMA_SATKER"].".docx";
			}else{
				$template = $this->config->item("path_client_tpl")."/perjanjian_kerja/eselonII.docx";
				$output_file_name = "PERJANJIAN KINERJA TAHUN ".$this->session->userdata('tahun')." - ".$data_satker["NAMA_SATKER"].".docx";
			}

			foreach ($data_sasaran as $key => $value) {

				$params_indikator = array(
					'ID_SASARAN' => $value["ID_SASARAN"],
					'TAHUN' => $this->session->userdata('tahun'),
					'TIPE' => $type
				);		

				$value["indikator_sasaran"] = $this->M_indikatorsasaran->get_indikatorsasaran($params_indikator)->result_array();
				$data_ss[] = $value;		

				$params_program = array(
					'ID_SASARAN' => $value["ID_SASARAN"],
					'TAHUN' => $this->session->userdata('tahun'),
				);	
				$res_program = $this->M_programsasaran->get_programsasaran($params_program)->result_array();			
				foreach ($res_program as $key2 => $value2) {
					$value2['TARGET'] = number_format($value2['TARGET'], 0 , '' , '.' );
					$data_program[] = $value2;
				}
			}

		}else if ($eselon == '3' || $eselon == '4') {

			if ($eselon == '3') {				
				$template = $this->config->item("path_client_tpl")."/perjanjian_kerja/eselonIII.docx";
			}else{
				$template = $this->config->item("path_client_tpl")."/perjanjian_kerja/eselonIV.docx";
			}

			$output_file_name = "PERJANJIAN KINERJA TAHUN ".$this->session->userdata('tahun')." - ".$data_satker["NAMA_SATKER"].".docx";

			foreach ($data_sasaran as $key => $value) {

				$params_indikator = array(
					'ID_SASARAN' => $value["ID_SASARAN"],
					'TAHUN' => $this->session->userdata('tahun'),
					'TIPE' => $type
				);		

				$value["indikator_sasaran"] = $this->M_indikatorsasaran->get_indikatorsasaran($params_indikator)->result_array();
				$kode_program = array_column($value["indikator_sasaran"], 'KODE_PROGRAM');
				$data_ss[] = $value;		

				if (count($kode_program) == 0) {
					$kode_program = array('-1'); // default jika tidak mempunyai program
				}
				$prog = implode(",", $kode_program);
				
				$res_program = $this->M_program->get_programbykode($prog)->result_array();			
				foreach ($res_program as $key2 => $value2) {
					$data_program[] = $value2;
				}
			}
			
		}else{
			//Pegawai

			$template = $this->config->item("path_client_tpl")."/perjanjian_kerja/pegawai.docx";			

			$output_file_name = "PERJANJIAN KINERJA TAHUN ".$this->session->userdata('tahun').".docx";
		}

		$TBS = $this->template_cetak->createNew("docx",$template);
		$TBS->MergeField("pihak_pertama",$data_satker);
		$TBS->MergeField("pihak_kedua",$data_atasan);
		$TBS->MergeField("TAHUN",$this->session->userdata('tahun'));
		$TBS->MergeField("SATKER",$data_satker["NAMA_SATKER"]);
		
		$TBS->MergeBlock("sasaran",$data_ss);
		$TBS->MergeBlock("program",$data_program);
		
		$TBS->Show(OPENTBS_DOWNLOAD, $output_file_name);
	}
}

/* End of file App.php */
/* Location: ./application/controllers/perjanjian_kinerja/App.php */