<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class App extends MY_Controller {

	public function __construct()
	{
		parent::__construct();
			$this->load->model(array('M_crud'));
	}


	public function get_news()
	{
		$table['table_name'] = "news";
		$params = array(
			'where' => "type",
			'where_value' => "1",
		 );
		$res =  $this->M_crud->get($params,$table)->result_array();
		echo json_encode($res);
	}

	public function get_galery()
	{
		$table['table_name'] = "news";
		$params = array(
			'where' => "type",
			'where_value' => "3",
		 );
		$res =  $this->M_crud->get($params,$table)->result_array();
		echo json_encode($res);
	}

	public function get_video()
	{
		$table['table_name'] = "news";
		$params = array(
			'where' => "type",
			'where_value' => "2",
		 );
		$res =  $this->M_crud->get($params,$table)->result_array();
		echo json_encode($res);
	}

	public function index()
	{
		$data = array(
			'data_app' => $this->get_data_app()
		);
		
		$this->template->display('inc/dashboard/main', $data);
	}

	public function tambah_news($arg="")
	{
		$data = array(
			'ID_SASARAN' => $arg,
			'data_app' => $this->get_data_app()
		);

		
		$this->template->display('inc/news/tambah', $data);
	}


	public function tambah_video($arg="")
	{
		$data = array(
			'ID_SASARAN' => $arg,
			'data_app' => $this->get_data_app()
		);

		
		$this->template->display('inc/news/tambah_video', $data);
	}

	public function tambah_galery($arg="")
	{
		$data = array(
			'ID_SASARAN' => $arg,
			'data_app' => $this->get_data_app()
		);

		
		$this->template->display('inc/news/tambah_galery', $data);
	}

	public function edit_news($value="")
	{
		$table['table_name'] = "news";
		$params = array(
			'where' => "id",
			'where_value' => $value,
		 );
		$data = array(
			'id' => $value,
			'data_app' => $this->get_data_app()
		);

		
		$this->template->display('inc/news/ubah', $data);
	}

	public function edit($value='')
	{
		$table['table_name'] = "news";
		$params = array(
			'where' => "id",
			'where_value' => $value,
		 );
		$res =  $this->M_crud->get($params,$table)->result_array();
		echo json_encode($res);
	}

	public function add()
	{
		$table['table_name'] = "news";
		$data = $this->input->post();
		$config = array(
            'upload_path'   => FCPATH2."client/uploads",  
            'allowed_types' => '*'              
		);
		if(isset($_FILES['userfile'])){
	    	$this->load->library('upload', $config);
	    	if (! $this->upload->do_upload()) {
		        $error = array('error' => $this->upload->display_errors()); 
		        print_r($error);
		    }else { 

		        $upload = $this->upload->data();
		      	$data['gambar'] = $upload['file_name'];
		    } 
		}
		$res = $this->M_crud->add($data,$table);
		if($res){
			$out = array(
							'success' => true,
							'msg' => 'Berhasil Memperbaharui',
				);
		}else{
			$out = array(
						'success' => false,
						'msg' => 'Gagal Memperbaharui',
			);
		}
		echo json_encode($out);
	}

	public function upd()
	{
		$table['table_name'] = "news";
		$data = $this->input->post();
		$config = array(
            'upload_path'   => FCPATH2."client/uploads",  
            'allowed_types' => '*'              
		);

		if($_FILES['userfile']['name']!=""){
	    	$this->load->library('upload', $config);
	    	if (! $this->upload->do_upload()) {
		        $error = array('error' => $this->upload->display_errors()); 
		        print_r($error);
		    }else { 

		        $upload = $this->upload->data();
		      	$data['gambar'] = $upload['file_name'];
		    } 
		}
		$data['where'] = 'id';
		$data['where_value'] = $data['id'];
		$res = $this->M_crud->upd($data,$table);
		if($res){
			$out = array(
							'success' => true,
							'msg' => 'Berhasil Memperbaharui',
				);
		}else{
			$out = array(
						'success' => false,
						'msg' => 'Gagal Memperbaharui',
			);
		}
		echo json_encode($out);
	}
}

/* End of file App.php */
/* Location: ./application/controllers/dashboard/App.php */