<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tantangan extends MY_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('M_tantangan');
	}

	public function get()
	{
		$params = array();

		$res = $this->M_tantangan->get($params);

		echo json_encode($res);
	}

	public function add()
	{
		$params = array(
			'NAMA_TANTANGAN' => ifunsetempty($_POST, 'NAMA_TANTANGAN', '')
		);

		$res = $this->M_tantangan->add($params);

		if ($res) {
			$out = array(
				'success' => TRUE,
				'msg' => 'Data berhasil disimpan'
			);

			echo json_encode($out);
		}
	}

	public function upd()
	{
		$params = array(
			'ID_TANTANGAN' => ifunsetempty($_POST, 'ID_TANTANGAN', ''),
			'NAMA_TANTANGAN' => ifunsetempty($_POST, 'NAMA_TANTANGAN', '')
		);

		$res = $this->M_tantangan->upd($params);

		if ($res) {
			$out = array(
				'success' => TRUE,
				'msg' => 'Data berhasil disimpan'
			);

			echo json_encode($out);
		}
	}

	public function del()
	{
		$params = array(
			'ID_TANTANGAN' => ifunsetempty($_POST, 'id', '')
		);

		$res = $this->M_tantangan->del($params);

		if ($res) {
			$out = array(
				'success' => TRUE,
				'msg' => 'Data berhasil dihapus'
			);

			echo json_encode($out);
		}
	}

}

/* End of file Tantangan.php */
/* Location: ./application/controllers/master/Tantangan.php */