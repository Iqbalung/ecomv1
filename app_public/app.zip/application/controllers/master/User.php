<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends MY_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('M_App');
	}

	public function get_usergroup()
	{
		$params = array();

		$res = $this->M_App->get_usergroup($params);
		
		echo json_encode($res);
	}

}

/* End of file User.php */
/* Location: ./application/controllers/master/User.php */