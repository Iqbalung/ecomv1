<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Satker extends MY_Controller{
	function __construct()
    {
		parent::__construct();
		$this->load->model(array('M_satker'));
	}
	
	function get_tree()
	{
		$params = array(
			'ID_SATKER' => ifunsetempty($_GET,'id',''),			
		);
		if ($params['ID_SATKER'] == '#') {
			$params['ID_SATKER'] = '';
			$is_root = true;
			$res_data = $this->M_satker->get($params);
		}else{
			$is_root = false;
			$res_data = $this->M_satker->get($params);
		}

		$res = $this->M_satker->get($params);
		$data = array();
		foreach ($res->result_array() as $key) {
			$id = $key['ID_SATKER'];	
			$params = array(
				'ID_SATKER' => $id,
			);
			$res_id = $this->M_satker->get($params);
			$data[] = $key;
		}

		

		$arr = array();
		foreach ($data as $key => $value) {
			$temp = $value;
			$temp["id"] = $value["ID_SATKER"];			
			//$temp["parent"] = $params['ID_SATKER'];
			$value["namajabatan_satker"] = "asas".$key;
			$value["spanclass"] = "second";
			$temp["data"] = (object) $value;			
			$temp["namajabatan_satker"] = "asas".$key;
			$temp["text"] = "<span class='text-overflow' data-toggle='tooltip' title='".$value['NAMA_SATKER']."'>".$value['NAMA_SATKER']."</span>";	
			if ($is_root) {
				$temp["state"] = array("opened"=>false,"selected"=>false);
			}
			$params_child = array(
				"ID_SATKER" => $value["ID_SATKER"]
			);
			$child = $this->M_satker->get($params_child);
			if ($child->num_rows() > 0) {
				$temp["children"] = true;
				$temp["icon"] = "fa fa-plus-square-o";
			}else{
				$temp["children"] = false;
				$temp["icon"] = "fa fa-minus";
			}
			$arr[] = $temp;
		}
		echo json_encode($arr);
	}

	function get_tree_()
	{
		$params = array(
			'ID_SATKER' => ifunsetempty($_GET,'id',''),			
		);
		if ($params['ID_SATKER'] == '#') {
			$params['ID_SATKER'] = '';
			$is_root = true;
			$res_data = $this->M_satker->get($params);
		}else{
			$is_root = false;
			$res_data = $this->M_satker->get($params);
		}

		$res = $this->M_satker->get($params);
		$data = array();
		foreach ($res->result_array() as $key) {
			$id = $key['ID_SATKER'];	
			$params = array(
				'ID_SATKER' => $id,
			);
			$res_id = $this->M_satker->get($params);
			$data[] = $key;
		}

		

		$arr = array();
		foreach ($data as $key => $value) {
			//$temp = $value;
			$temp["id"] = $value["ID_SATKER"];			
			
			//$temp["parent"] = $params['ID_SATKER'];			
			$temp["data"] = $value;			
			$temp["text"] = $value['NAMA_SATKER'];

			$temp["text"]  = "".
					"<span class='col-md-4 max'>".$value["NAMA_SATKER"]."</span>".
					"<span class='col-md-2 max'>".$value["NAMAJABATAN_SATKER"]."</span>".
					"<span class='col-md-2 max'>".$value["NAMA_PEJABAT_SATKER"]."</span>".
					"<span class='col-md-2 max'>".$value["NIP_PEJABAT_SATKER"]."</span>".
					"<span class='col-md-2 max'>".$value["PANGKAT_PEJABAT_SATKER"]."</span>".
					"";

			$params_child = array(
				"ID_SATKER" => $value["ID_SATKER"]
			);

			$child = $this->M_satker->get($params_child);

			if ($child->num_rows() > 0) {
				$temp["children"] = true;				
			}else{
				$temp["children"] = false;
				
			}
			$arr[] = $temp;
		}
		echo json_encode($arr);
	}


	function save(){
		$params = array(			
			'ID_SATKER' => ifunsetempty($_POST, 'ID_SATKER',''),			
			'NAMA_SATKER' => ifunsetempty($_POST,'NAMA_SATKER',''),		
			'NAMAJABATAN_SATKER' => ifunsetempty($_POST,'NAMAJABATAN_SATKER',''),
			'NAMA_PEJABAT_SATKER' => ifunsetempty($_POST,'NAMA_PEJABAT_SATKER',''),
			'NIP_PEJABAT_SATKER' => ifunsetempty($_POST,'NIP_PEJABAT_SATKER',''),
			'PANGKAT_PEJABAT_SATKER' => ifunsetempty($_POST,'PANGKAT_PEJABAT_SATKER','')
		);
		$id_parent = ifunsetempty($_POST, 'ID_SATKER_PARENT','');
		if($params['ID_SATKER'] == ""){
			$params['ID_SATKER'] = str_replace('_anchor', ' ', $id_parent);
				// Jika submit update null maka lakukan insert
			$new_id = $this->M_satker->get_id($params)->first_row()->NEW;
			$params['ID_SATKER'] = $params['ID_SATKER'] . $new_id.'.';									
			$res = $this->M_satker->add($params);
			if($res){
				$out = array(
					'success' => true,
					'msg' => 'Berhasil Menyimpan',
					'new_id' =>$params['ID_SATKER'],
					'id_parent' => $id_parent
				);
			}	
		}else{			
			$params['ID_SATKER'] = str_replace('_anchor', '', $params['ID_SATKER']);
			$res = $this->M_satker->upd($params);
			$out = array(
					'success' => true,
					'msg' => 'Berhasil Memperbaharui',
					'new_id' =>$params['ID_SATKER'],
					'id_parent' => $id_parent
				);

		}
		echo json_encode($out);
	}

	function upd(){
		$params = array(
			'ID_SATKER' => ifunsetempty($_POST, 'ID_SATKER',''),
			'NAMA_SATKER' => ifunsetempty($_POST,'NAMA_SATKER',''),
		);

		$params['ID_SATKER'] = str_replace('_anchor', ' ', $params['ID_SATKER']);
		$new_id = $this->M_satker->get_id($params)->first_row()->NEW;
		$params['ID_SATKER'] = $params['ID_SATKER'] . $new_id.'.';
		$res = $this->M_satker->add($params);
			if($res){
				$out = array(
					'success' => true,
					'msg' => 'Berhasil Menyimpan',
					'new_id' =>$params['ID_SATKER']
				);
			}	
		
		echo json_encode($out);
	}

	function del(){
		$params = array(
			'ID_SATKER' => ifunsetempty($_POST,'ID_SATKER',''),
		);
		$params['ID_SATKER'] = str_replace('_anchor', '', $params['ID_SATKER']);
		$res = $this->M_satker->del($params);
		if($res){
					$out = array(
						'success' => true,
						'msg' => 'Berhasil Menghapus' 
					);
				}
		echo json_encode($out);
	}


}
