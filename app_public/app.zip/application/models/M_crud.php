<?php
class M_crud extends CI_Model{

	function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
	function get($params,$table)
	{
		$this->db->where($params['where'],$params['where_value']);
		$q = $this->db->get($table['table_name']);
		return $q;	
	}


	function add($params,$table)
	{
		$res = $this->db->insert($table['table_name'],$params); 
		return $res;
	}

	function upd($params,$table)
	{
		$this->db->where($params['where'],$params['where_value']);
		unset($params['where']);
		unset($params['where_value']);
		$res = $this->db->update($table['table_name'], $params);
		return $res;
	}
}