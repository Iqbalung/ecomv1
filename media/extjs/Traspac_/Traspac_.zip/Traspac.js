var Traspac={
	version:'1.0.0',
	name:'TRASPAC',
	verdor:'PT. TRASPAC MAKMUR SEJAHTERA',
	description:'Libraries For Building EHCM Application',
	upgrade :'21 Sep 2014',
};